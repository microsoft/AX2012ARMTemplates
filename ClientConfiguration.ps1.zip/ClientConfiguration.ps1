#
# ClientConfiguration.ps1
#

configuration CommonSetup {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	Import-DSCResource -ModuleName xComputerManagement, xPSDesiredStateConfiguration

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		xComputer DomainJoin {
			Name = $env:COMPUTERNAME
			DomainName = $domainName
			Credential = $adminCreds
		}

		Group AddToAdmin {
			DependsOn = "[xComputer]DomainJoin"

			GroupName = "Administrators"
			Ensure = "Present"
			MembersToInclude = "$($adminCreds.UserName)"
			Credential = $adminCreds
		}
	}
}

configuration DownloadAXSetup {
	
	param (
		[Parameter(Mandatory)]
		[String]$fileAxSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileAxSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	Node localhost {

		xRemoteFile AXSetup {
			Uri = $fileAxSetupUri
			DestinationPath = $outputFile
		}

		xZipExtract ExtractAXSetup {
			DependsOn = "[xRemoteFile]AXSetup"

			SourceFile = $outputFile
			Destination = $outputPath
		}
	}
}

configuration PrepareUpdatesAndHotFixes {
	
	param (
		[Parameter(Mandatory)]
		[String]$fileAxSetupUpdatesPath,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$updatesPath = Join-Path $extractedPath -ChildPath Updates

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	$regex = ".+\/(.+)"

	Node localhost {

		$counter = 0

		foreach($package in $cumulativeUpdatesAndHotFixes)
		{
			$fileName = $package -replace $regex, '$1'
			$fileName = Join-Path $updatesPath -ChildPath $fileName

			$remoteFileResource = "RemoteFile$counter"
			$zipExtractResource = "ZipExtract$counter"

			xRemoteFile $remoteFileResource {
			Uri = $package
			DestinationPath = $fileName
			}

			xZipExtract $zipExtractResource {
				DependsOn = "[xRemoteFile]$remoteFileResource"

				SourceFile = $fileName
				Destination = $updatesPath
			}

			$counter++
		}
	}
}

configuration DownloadAndInstallMSChart {

	param(
		[Parameter(Mandatory)]
		[String]$fileMSChartSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileMSChartSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadMSChart {
			Uri = $fileMSChartSetupUri
			DestinationPath = $outputFile
		}

		Package InstallMSChart {
			DependsOn = "[xRemoteFile]DownloadMSChart"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft Chart Controls for Microsoft .NET Framework 3.5"
			ProductId = "41785C66-90F2-40CE-8CB5-1C94BFC97280"
			Arguments = "/q"
		}
	}
}

configuration DownloadAndInstallSQLSysClrTypes {

	param (
		[Parameter(Mandatory)]
		[String]$fileSqlSysClrTypesSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileSqlSysClrTypesSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLSysClrTypes {
			Uri = $fileSqlSysClrTypesSetupUri
			DestinationPath = $outputFile
		}

		Package InstallSQLSysClrTypes {
			DependsOn = "[xRemoteFile]DownloadSQLSysClrTypes"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft System CLR Types for SQL Server 2012 (x64)"
			ProductId = "F1949145-EB64-4DE7-9D81-E6D27937146C"
		}
	}
}

configuration DownloadAndInstallSQLAMO {

	param (
		[Parameter(Mandatory)]
		[String]$fileSqlAMOSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileSqlAMOSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLAMO {
			Uri = $fileSqlAMOSetupUri
			DestinationPath = $outputFile
		}

		Package InstallSQLAMO {
			DependsOn = "[xRemoteFile]DownloadSQLAMO"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft SQL Server 2008 Analysis Management Objects"
			ProductId = "A2C487D8-EA61-4083-B589-58BED96C7D45"
		}
	}
}

configuration DownloadAndInstallSQLADOMD {

	param (
		[Parameter(Mandatory)]
		[String]$fileSqlADOMDSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileSqlADOMDSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLADOMD {
			Uri = $fileSqlADOMDSetupUri
			DestinationPath = $outputFile
		}

		Package InstallSQLADOMD {
			DependsOn = "[xRemoteFile]DownloadSQLADOMD"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft SQL Server 2008 R2 ADOMD.NET"
			ProductId = "DE81CA12-BA88-4D4F-BAF2-12DD94A9EF35"
		}
	}
}

configuration DownloadAndInstallReportViewer {

	param (
		[Parameter(Mandatory)]
		[String]$fileReportViewerSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileReportViewerSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadReportViewer {
			Uri = $fileReportViewerSetupUri
			DestinationPath = $outputFile
		}

		Package InstallReportViewer {
			DependsOn = "[xRemoteFile]DownloadReportViewer"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft Report Viewer 2012 Runtime"
			ProductId = "C58378BC-0B7B-474E-855C-9D02E5E75D71"
		}
	}
}

configuration ClientMachine {

	param (
		[Parameter(Mandatory)]
		[String]$aosServer,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[String[]]$cumulativeUpdatesAndHotFixes,

		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
        [PSCredential]$dynamicsInstallationCreds,

		[Parameter(Mandatory)]
		[String]$fileAxSetupPath,

		[Parameter(Mandatory)]
		[String]$fileAxSetupUpdatesPath,

		[Parameter(Mandatory)]
		[String]$fileAxSetupUri,

		[Parameter(Mandatory)]
		[String]$fileMSChartSetupUri,

		[Parameter(Mandatory)]
		[String]$fileReportViewerSetupUri,

		[Parameter(Mandatory)]
		[String]$fileSqlADOMDSetupUri,

		[Parameter(Mandatory)]
		[String]$fileSqlAMOSetupUri,

		[Parameter(Mandatory)]
		[String]$fileSqlSysClrTypesSetupUri
	)

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$setupFile = Join-Path $outputPath -ChildPath $fileAxSetupPath

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost, xComputerManagement, xDynamicsAX2012R3

	Node localhost {

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

		WindowsFeature NET-Framework-Core {
			DependsOn = "[CommonSetup]CommonSetup"

			Ensure = "Present"
			Name = "NET-Framework-Core"
		}

		WindowsFeature RDS-RD-Server {
			DependsOn = "[WindowsFeature]NET-Framework-Core"

			Ensure = "Present"
			Name = "RDS-RD-Server"
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[WindowsFeature]RDS-RD-Server"

			FileAxSetupUri = $fileAxSetupUri
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			fileAxSetupUpdatesPath = $fileAxSetupUpdatesPath
			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		DownloadAndInstallMSChart DownloadAndInstallMSChart {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			fileMSChartSetupUri = $fileMSChartSetupUri
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes{
			DependsOn = "[DownloadAndInstallMSChart]DownloadAndInstallMSChart"

			fileSqlSysClrTypesSetupUri = $fileSqlSysClrTypesSetupUri
		}

		DownloadAndInstallSQLAMO DownloadAndInstallSQLAMO{
			DependsOn = "[DownloadAndInstallSQLSysClrTypes]DownloadAndInstallSQLSysClrTypes"

			fileSqlAMOSetupUri = $fileSqlAMOSetupUri
		}

		DownloadAndInstallSQLADOMD DownloadAndInstallSQLADOMD{
			DependsOn = "[DownloadAndInstallSQLAMO]DownloadAndInstallSQLAMO"

			fileSqlADOMDSetupUri = $fileSqlADOMDSetupUri
		}

		DownloadAndInstallReportViewer DownloadAndInstallReportViewer{
			DependsOn = "[DownloadAndInstallSQLADOMD]DownloadAndInstallSQLADOMD"

			fileReportViewerSetupUri = $fileReportViewerSetupUri
		}

		xDynamicsClient DynamicsClient {
			DependsOn = "[DownloadAndInstallReportViewer]DownloadAndInstallReportViewer"

			Ensure = "Present"
			aosServer = $aosServer
			aosWsdlPort = $aosWsdlPort
			setupFile = $setupFile

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}
	}
}