#
# DatabaseConfiguration.ps1
#

configuration CommonSetup {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	Import-DSCResource -ModuleName xComputerManagement, xPSDesiredStateConfiguration

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		xComputer DomainJoin {
			Name = $env:COMPUTERNAME
			DomainName = $domainName
			Credential = $adminCreds
		}

		Group AddToAdmin {
			DependsOn = "[xComputer]DomainJoin"
			GroupName = "Administrators"
			Ensure = "Present"
			MembersToInclude = "$($adminCreds.UserName)"
			Credential = $adminCreds
		}
	}
}

configuration DownloadAXSetup {
	
	param (
		[Parameter(Mandatory)]
		[String]$fileAxSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileAxSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	Node localhost {

		xRemoteFile AXSetup {
			Uri = $fileAxSetupUri
			DestinationPath = $outputFile
		}

		xZipExtract ExtractAXSetup {
			DependsOn = "[xRemoteFile]AXSetup"

			SourceFile = $outputFile
			Destination = $outputPath
		}
	}
}

configuration PrepareUpdatesAndHotFixes {
	
	param (
		[Parameter(Mandatory)]
		[String]$fileAxSetupUpdatesPath,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$updatesPath = Join-Path $extractedPath -ChildPath Updates

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	$regex = ".+\/(.+)"

	Node localhost {

		$counter = 0

		foreach($package in $cumulativeUpdatesAndHotFixes)
		{
			$fileName = $package -replace $regex, '$1'
			$fileName = Join-Path $updatesPath -ChildPath $fileName

			$remoteFileResource = "RemoteFile$counter"
			$zipExtractResource = "ZipExtract$counter"

			xRemoteFile $remoteFileResource {
			Uri = $package
			DestinationPath = $fileName
			}

			xZipExtract $zipExtractResource {
				DependsOn = "[xRemoteFile]$remoteFileResource"

				SourceFile = $fileName
				Destination = $updatesPath
			}

			$counter++
		}
	}
}

configuration SQLWitnessMachine {
	param
    (
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$dynamicsInstallationCreds,

        [Parameter(Mandatory)]
        [String]$sharePath,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xSmbShare, cDisk, xDisk, xActiveDirectory
    
    Node localhost
    {
		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

        xWaitforDisk Disk2
        {
			DependsOn = "[CommonSetup]CommonSetup"

             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
			DependsOn = "[xWaitforDisk]Disk2"

            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature ADPS
        {
			DependsOn = "[cDiskNoRestart]DataDisk"

            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        File FSWFolder
        {
			DependsOn = "[WindowsFeature]ADPS"

            DestinationPath = "F:\$($sharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
        }

        xSmbShare FSWShare
        {
			DependsOn = "[File]FSWFolder"

            Name = $sharePath.ToUpperInvariant()
            Path = "F:\$($sharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators"
            Ensure = "Present"
        }
    }
}

configuration SQLAlwaysOnPrepare {
	
	param
    (
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$dynamicsInstallationCreds,

		[Parameter(Mandatory)]
        [PSCredential]$localAdminCreds,

		[Parameter(Mandatory)]
        [String]$SqlAlwaysOnEndpointName,

		[Parameter(Mandatory)]
        [PSCredential]$sqlServiceCreds,

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    )

    Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xActiveDirectory, cDisk, xDisk, xSQL, xSQLServer, xSqlPs, xNetworking

	$dynamicsInstallationCredsUserName = $($dynamicsInstallationCreds.UserName).split('\')[-1]

    $domainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$dynamicsInstallationCredsUserName", $dynamicsInstallationCreds.Password)
	$localCreds = New-Object System.Management.Automation.PSCredential ("$env:COMPUTERNAME\$($localAdminCreds.UserName)", $localAdminCreds.Password)

    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
			DependsOn = "[xWaitforDisk]Disk2"

            DiskNumber = 2
            DriveLetter = "F"
        }

        xWaitforDisk Disk3
        {
			DependsOn = "[cDiskNoRestart]DataDisk"

             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart LogDisk
        {
			DependsOn = "[xWaitforDisk]Disk3"

            DiskNumber = 3
            DriveLetter = "G"
        }

        WindowsFeature FC
        {
			DependsOn = "[cDiskNoRestart]LogDisk"

            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
			DependsOn = "[WindowsFeature]FC"

            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
			DependsOn = "[WindowsFeature]FCPS"

            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        CommonSetup CommonSetup {
			DependsOn = "[WindowsFeature]ADPS"

			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

        xFirewall DatabaseEngineFirewallRule
        {
			DependsOn = "[CommonSetup]CommonSetup"

			Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            Action = "Allow"
            LocalPort = "1433"
        }

        xFirewall DatabaseMirroringFirewallRule
        {
			DependsOn = "[xFirewall]DatabaseEngineFirewallRule"

			Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
            Enabled = "True"
			Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            Action = "Allow"
            LocalPort = "5022"
        }

        xFirewall ListenerFirewallRule
        {
			DependsOn = "[xFirewall]DatabaseMirroringFirewallRule"

			Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            Action = "Allow"
            LocalPort = "59999"
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
			DependsOn = "[xFirewall]ListenerFirewallRule"

            Name = $dynamicsInstallationCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $localCreds
        }

		xSqlLogin AddSqlServiceAccountToSysadminServerRole
        {
			DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"

            Name = $sqlServiceCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $localCreds
        }

        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
			DependsOn = "[xSqlLogin]AddSqlServiceAccountToSysadminServerRole"

            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $localCreds
            ServiceCredential = $sqlServiceCreds
            MaxDegreeOfParallelism = 1
            FilePath = "F:\DATA"
            LogPath = "G:\LOG"
            DomainAdministratorCredential = $DomainFQDNCreds
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }
    }
}

configuration SQLAlwaysOnCreateCluster {

	param
    (
		[Parameter(Mandatory)]
        [String]$clusterName,

		[String[]]$cumulativeUpdatesAndHotFixes,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

        [Parameter(Mandatory)]
        [String]$domainName,

		[Parameter(Mandatory)]
        [PSCredential]$dynamicsInstallationCreds,

		[Parameter(Mandatory)]
		[String]$fileAxSetupPath,

		[Parameter(Mandatory)]
		[String]$fileAxSetupUpdatesPath,

		[Parameter(Mandatory)]
		[String]$fileAxSetupUri,

		[Parameter(Mandatory)]
        [String]$lbAddress,

		[Parameter(Mandatory)]
        [String]$lbName,

		[Parameter(Mandatory)]
        [PSCredential]$localAdminCreds,

        [Parameter(Mandatory)]
        [String[]]$nodes,

		[Parameter(Mandatory)]
        [String]$primaryReplica,

        [Parameter(Mandatory)]
        [String]$secondaryReplica,
		
        [Parameter(Mandatory)]
        [String]$sharePath,

		[Parameter(Mandatory)]
        [String]$sqlAlwaysOnAvailabilityGroupListenerName,

        [Parameter(Mandatory)]
        [String]$sqlAlwaysOnAvailabilityGroupName,

        [Parameter(Mandatory)]
        [String]$sqlAlwaysOnEndpointName,

        [Parameter(Mandatory)]
        [PSCredential]$sqlServiceCreds,

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    )

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xActiveDirectory, cDisk, xDisk, xSQL, xSQLServer, xSqlPs, xNetworking, xFailOverCluster, xCredSSP, xDynamicsAX2012R3

	$dynamicsInstallationCredsUserName = $($dynamicsInstallationCreds.UserName).split('\')[-1]

    $domainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$dynamicsInstallationCredsUserName", $dynamicsInstallationCreds.Password)
	$localCreds = New-Object System.Management.Automation.PSCredential ("$env:COMPUTERNAME\$($localAdminCreds.UserName)", $localAdminCreds.Password)

	$lbFQName="$lbName.$domainName"

	$localhost = $env:COMPUTERNAME
	$localhostFqdn = "$localhost.$domainName"

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$setupFile = Join-Path $outputPath -ChildPath $fileAxSetupPath

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $True
        }

		xCredSSP Server {
            Ensure = "Present"
            Role = "Server"
        }

		xCredSSP Client {
			DependsOn = "[xCredSSP]Server"

            Ensure = "Present"
            Role = "Client"
            DelegateComputers = $localhostFqdn
        }

        xWaitforDisk Disk2
        {
			DependsOn = "[xCredSSP]Client"

             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
			DependsOn = "[xWaitforDisk]Disk2"

            DiskNumber = 2
            DriveLetter = "F"
        }

        xWaitforDisk Disk3
        {
			DependsOn = "[cDiskNoRestart]DataDisk"

             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart LogDisk
        {
			DependsOn = "[xWaitforDisk]Disk3"

            DiskNumber = 3
            DriveLetter = "G"
        }

        WindowsFeature FC
        {
			DependsOn = "[cDiskNoRestart]LogDisk"

            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
			DependsOn = "[WindowsFeature]FC"

            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
			DependsOn = "[WindowsFeature]FCPS"

            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
        
		CommonSetup CommonSetup {
			DependsOn = "[WindowsFeature]ADPS"

			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

        xCluster FailoverCluster
        {
			DependsOn = "[CommonSetup]CommonSetup"

            Name = $clusterName
            DomainAdministratorCredential = $dynamicsInstallationCreds
            Nodes = $nodes
        }

        xWaitForFileShareWitness WaitForFSW
        {
			DependsOn = "[xCluster]FailoverCluster"

            SharePath = $sharePath
            DomainAdministratorCredential = $dynamicsInstallationCreds
        }

        xClusterQuorum FailoverClusterQuorum
        {
			DependsOn = "[xWaitForFileShareWitness]WaitForFSW"

            Name = $clusterName
            SharePath = $sharePath
            DomainAdministratorCredential = $dynamicsInstallationCreds
        }

        Script DisableStorageClustering
        {
			DependsOn = "[xClusterQuorum]FailoverClusterQuorum"

            SetScript =  "Get-StorageSubsystem -FriendlyName 'Clustered Storage Spaces*' | Set-StorageSubSystem -AutomaticClusteringEnabled `$False"
            TestScript = "!(Get-StorageSubsystem -FriendlyName 'Clustered Storage Spaces*').AutomaticClusteringEnabled"
            GetScript = "@{Ensure = if (!(Get-StorageSubsystem -FriendlyName 'Clustered Storage Spaces*').AutomaticClusteringEnabled) {'Present'} else {'Absent'}}"
        }

        Script IncreaseClusterTimeouts
        {
			DependsOn = "[Script]DisableStorageClustering"

            SetScript = "(Get-Cluster).SameSubnetDelay = 2000; (Get-Cluster).SameSubnetThreshold = 15; (Get-Cluster).CrossSubnetDelay = 3000; (Get-Cluster).CrossSubnetThreshold = 15"
            TestScript = "(Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15"
            GetScript = "@{Ensure = if ((Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15) {'Present'} else {'Absent'}}"
        }

        xFirewall DatabaseEngineFirewallRule
        {
			DependsOn = "[Script]IncreaseClusterTimeouts"

			Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            Action = "Allow"
            LocalPort = "1433"
        }

        xFirewall DatabaseMirroringFirewallRule
        {
			DependsOn = "[xFirewall]DatabaseEngineFirewallRule"

			Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            Action = "Allow"
            LocalPort = "5022"
        }

        xFirewall ListenerFirewallRule
        {
			DependsOn = "[xFirewall]DatabaseMirroringFirewallRule"

			Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
			Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            Action = "Allow"
            LocalPort = "59999"
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
			DependsOn = "[xFirewall]ListenerFirewallRule"

            Name = $dynamicsInstallationCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $localCreds
        }

		xSqlLogin AddSqlServiceAccountToSysadminServerRole
        {
			DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"

            Name = $sqlServiceCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $localCreds
        }

        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
			DependsOn = "[xSqlLogin]AddSqlServiceAccountToSysadminServerRole"

            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $dynamicsInstallationCreds
            ServiceCredential = $sqlServiceCreds
            Hadr = "Enabled"
            MaxDegreeOfParallelism = 1
            FilePath = "F:\DATA"
            LogPath = "G:\LOG"
            DomainAdministratorCredential = $DomainFQDNCreds
        }

        xSqlEndpoint SqlAlwaysOnEndpoint
        {
			DependsOn = "[xSqlServer]ConfigureSqlServerWithAlwaysOn"

            InstanceName = $env:COMPUTERNAME
            Name = $sqlAlwaysOnEndpointName
            PortNumber = 5022
            AllowedUser = $sqlServiceCreds.UserName
            SqlAdministratorCredential = $sqlServiceCreds
        }

        xSqlServer ConfigureSqlServerSecondaryWithAlwaysOn
        {
			DependsOn = "[xSqlEndPoint]SqlAlwaysOnEndpoint"

            InstanceName = $secondaryReplica
            SqlAdministratorCredential = $sqlServiceCreds
            Hadr = "Enabled"
            DomainAdministratorCredential = $DomainFQDNCreds
        }

        xSqlEndpoint SqlSecondaryAlwaysOnEndpoint
        {
			DependsOn = "[xSqlServer]ConfigureSqlServerSecondaryWithAlwaysOn"

            InstanceName = $secondaryReplica
            Name = $sqlAlwaysOnEndpointName
            PortNumber = 5022
            AllowedUser = $sqlServiceCreds.UserName
            SqlAdministratorCredential = $sqlServiceCreds
        }

        xSqlAvailabilityGroup SqlAG
        {
			DependsOn = "[xSqlEndpoint]SqlSecondaryAlwaysOnEndpoint"

            Name = $sqlAlwaysOnAvailabilityGroupName
            ClusterName = $clusterName
            InstanceName = $env:COMPUTERNAME
            PortNumber = 5022
            DomainCredential = $dynamicsInstallationCreds
            SqlAdministratorCredential = $sqlServiceCreds
        }

        xSqlAvailabilityGroupListener SqlAGListener
        {
			DependsOn = "[xSqlAvailabilityGroup]SqlAG"

            Name = $sqlAlwaysOnAvailabilityGroupListenerName
            AvailabilityGroupName = $sqlAlwaysOnAvailabilityGroupName
            DomainNameFqdn = $lbFQName
            LBAddress=$lbAddress
            ListenerPortNumber = 1433
            ProbePortNumber = 59999
            InstanceName = $env:COMPUTERNAME
            DomainCredential = $dynamicsInstallationCreds
            SqlAdministratorCredential = $sqlServiceCreds
        }

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[xSqlAvailabilityGroupListener]SqlAGListener"

			FileAxSetupUri = $fileAxSetupUri
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			fileAxSetupUpdatesPath = $fileAxSetupUpdatesPath
			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsDatabase DynamicsDatabase {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			dbSqlServer = "localhost"
			dbSqlServerDatabase = $dbSqlServerDatabase
			setupFile = $setupFile

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		xSqlNewAGDatabase SQLAGDatabases
        {
			DependsOn = "[xDynamicsDatabase]DynamicsDatabase"

            SqlAlwaysOnAvailabilityGroupName = $SqlAlwaysOnAvailabilityGroupName
            DatabaseNames = $dbSqlServerDatabase
            PrimaryReplica = $PrimaryReplica
            SecondaryReplica = $SecondaryReplica
            SqlAdministratorCredential = $sqlServiceCreds
        }

        xSqlTestAGDatabase SQLAGDatabasesVerification
        {
			DependsOn = "[xSqlNewAGDatabase]SQLAGDatabases"

            SqlAlwaysOnAvailabilityGroupName = $SqlAlwaysOnAvailabilityGroupName
            InstanceName = $env:COMPUTERNAME
            DomainCredential = $dynamicsInstallationCreds
        }
	}
}