#######################################################################
# The Get-TargetResource cmdlet.
#######################################################################
function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ValidationKey,
		
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DecryptionKey
    )

    $result = $null

    write-verbose "Getting RD Web Access configuration"
    
    $config = Get-WebConfiguration -PSPath 'IIS:\Sites\Default Web Site\RDWeb' -Filter '/system.web/machinekey'

    if ($config)
    {
        write-verbose "configuration retrieved successfully:"

        $result = 
        @{
            "ValidationKey" = $config.ValidationKey
            "DecryptionKey" = $config.DecryptionKey
        }
    }
    else
    {
        write-verbose "Failed to retrieve RD WebAccess configuration."
    }

    $result
}


######################################################################## 
# The Set-TargetResource cmdlet.
########################################################################
function Set-TargetResource
{
    [CmdletBinding()]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ValidationKey,
		
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DecryptionKey
    )

	$RDWebSitePath = 'IIS:\Sites\Default Web Site\RDWeb'
	$RDWebConfigFilter = '/system.web/machinekey'
	
    write-verbose "Starting RD WebAccess configuration..."

	$config = Get-WebConfiguration -PSPath $RDWebSitePath -Filter $RDWebConfigFilter
	
	if ($config)
	{
		$config.validationKey = $ValidationKey
		$config.decryptionKey = $DecryptionKey
		
		$config | Set-WebConfiguration -PSPath $RDWebSitePath -Filter $RDWebConfigFilter
	}

    write-verbose "Set-RdDeploymentGatewayConfiguration done."
}


#######################################################################
# The Test-TargetResource cmdlet.
#######################################################################
function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ValidationKey,
		
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DecryptionKey
    )


    $config = Get-TargetResource @PSBoundParameters
    
    if ($config)
    {
        write-verbose "verifying RD WebAccess configuration..."
        $result =  ($config.validationKey -ieq $ValidationKey -and $config.decryptionKey -ieq $DecryptionKey)
    }
    else
    {
        write-verbose "Failed to retrieve RD WebAccess configuration."
        $result = $false
    }

    write-verbose "Test-TargetResource returning:  $result"
    return $result
}


Export-ModuleMember -Function *-TargetResource
