if ([System.Environment]::OSVersion.Version -lt "6.2.9200.0") { Throw "The minimum OS requirement was not met."}

Import-Module RemoteDesktop


#######################################################################
# The Get-TargetResource cmdlet.
#######################################################################
function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionBroker,
        
		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ClientAccessName,
        
		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseConnectionString,
		
		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseFilePath
    )

    $result = $null

    write-verbose "Getting high availability settings for '$ConnectionBroker'..."    

    $settings = Get-RDConnectionBrokerHighAvailability -ConnectionBroker $ConnectionBroker -ea SilentlyContinue


    if ($settings)
    {
        write-verbose "Found connection broker high availability"

        $result = 
        @{
			"ActiveManagementServer" = $settings.ActiveManagementServer
            "ConnectionBroker" = $settings.ConnectionBroker
            "ClientAccessName"  = $settings.ClientAccessName
            "DatabaseConnectionString" = $settings.DatabaseConnectionString
			"DatabaseFilePath" = $settings.DatabaseFilePath
        }
    }
    else
    {
        write-verbose "The RD Connection Broker server is not configured for high availability on '$ConnectionBroker'."
    }

    $result
}


######################################################################## 
# The Set-TargetResource cmdlet.
########################################################################
function Set-TargetResource
{
    [CmdletBinding()]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionBroker,

		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ClientAccessName,

		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseConnectionString,
		
		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseFilePath
    )


    write-verbose "Setting connection broker high availability on '$ConnectionBroker'..."

    write-verbose ">> RD Connection Broker:     $($ConnectionBroker.ToLower())"

    write-verbose "calling Set-RDConnectionBrokerHighAvailability cmdlet..."
    #{
        Set-RDConnectionBrokerHighAvailability @PSBoundParameters
    #}
    write-verbose "Set-RDConnectionBrokerHighAvailability done."

 
  # write-verbose "RD Session deployment done, setting reboot flag..."
  # $global:DSCMachineStatus = 1
}


#######################################################################
# The Test-TargetResource cmdlet.
#######################################################################
function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionBroker,

		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ClientAccessName,

		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseConnectionString,
		
		[parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DatabaseFilePath
    )


    write-verbose "Checking whether Remote Desktop deployment exists on server '$ConnectionBroker'..."

    $connectionbrokerhighavailability = Get-TargetResource @PSBoundParameters
    
    if ($connectionbrokerhighavailability)
    {
        write-verbose "verifying RD Connection broker name..."
        $result =  ($connectionbrokerhighavailability.ActiveManagementServer -ieq $ConnectionBroker)
    }
    else
    {
        write-verbose "The RD Connection Broker server is not configured for high availability."
        $result = $false
    }

    write-verbose "Test-TargetResource returning:  $result"
    return $result
}


Export-ModuleMember -Function *-TargetResource
