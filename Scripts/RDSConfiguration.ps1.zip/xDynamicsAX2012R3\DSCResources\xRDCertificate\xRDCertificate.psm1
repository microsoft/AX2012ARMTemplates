if ([System.Environment]::OSVersion.Version -lt "6.2.9200.0") { Throw "The minimum OS requirement was not met."}

Import-Module RemoteDesktop

function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionBroker,
        
        [ValidateNotNullOrEmpty()]
        [string] $Password,
		
		[string] $DnsName
    )

	#Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."


    <#
    $returnValue = @{
    Domain = [System.String]
    Username = [System.String]
    }

    $returnValue
    #>

    return @{}
}

function Set-TargetResource
{
    [CmdletBinding()]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionBroker,
        
        [ValidateNotNullOrEmpty()]
        [string] $Password,
		
		[string] $DnsName
    )

	$certPath = Join-Path $env:TEMP -ChildPath rdsCertificate.pfx

	# Gateway
	Write-Verbose "Setting new certificate for Gateway role"

	$gatewayJob = Start-Job -ScriptBlock {
		param ($DnsName, $Password, $ConnectionBroker, $CertPath)
		Import-Module RemoteDesktop
		$SecPassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
		New-RDCertificate -Role RDGateway -DnsName $DnsName -Password $SecPassword -ConnectionBroker $ConnectionBroker -ExportPath $certPath -Force
	} -ArgumentList $DnsName, $Password, $ConnectionBroker, $certPath

	$gatewayJob | Wait-Job | Receive-Job

	# Web Access
	Write-Verbose "Setting the same certificate for WebAccess role"

	$webAccessJob = Start-Job -ScriptBlock {
		param($ConnectionBroker, $certPath, $Password)
		Import-Module RemoteDesktop
		$SecPassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
		Set-RDCertificate -Role RDWebAccess -ConnectionBroker $ConnectionBroker -ImportPath $certPath -Password $SecPassword -Force
	} -ArgumentList $ConnectionBroker, $certPath, $Password

	$webAccessJob | Wait-Job | Receive-Job

	# Redirector
	Write-Verbose "Setting the same certificate for Redirector role"

	$redirectorJob = Start-Job -ScriptBlock {
		param($ConnectionBroker, $certPath, $Password)
		Import-Module RemoteDesktop
		$SecPassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
		Set-RDCertificate -Role RDRedirector -ConnectionBroker $ConnectionBroker -ImportPath $certPath -Password $SecPassword -Force
	} -ArgumentList $ConnectionBroker, $certPath, $Password

	$redirectorJob | Wait-Job | Receive-Job
 
  # write-verbose "RD Session deployment done, setting reboot flag..."
  # $global:DSCMachineStatus = 1
}

function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (    
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ConnectionBroker,
        
        [ValidateNotNullOrEmpty()]
        [string] $Password,
		
		[string] $DnsName
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."


    <#
    $result = [System.Boolean]
    
    $result
    #>

	return $false
}


Export-ModuleMember -Function *-TargetResource
