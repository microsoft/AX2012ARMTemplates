#
# AX2012R3Deployment.psm1
#

# Executes the AX setup with the parameters file provided
function Run-AXSetup
{
	param
	(
		[System.String]
		$parmFileName,

		[System.String]
		$setupFile,

		[System.String]
		$logDir
	)

	$hostName = $env:COMPUTERNAME

	try
	{
		Write-Verbose "Running Microsoft Dynamics AX Setup with parm file = $parmFileName as user $env:USERNAME"
		Write-Verbose "Command: Start-Process '$setupFile' -ArgumentList parmfile=`"$parmFileName`" -Wait"
        
		$process = (Start-Process $setupFile -ArgumentList "parmfile=`"$parmFileName`"" -Wait -PassThru)

		if (!$?)
		{
			Write-Verbose "Microsoft Dynamics AX Setup failed on $hostName. Inspect the setup logs at $logDir for details."
		}

		Write-Verbose "Setup.exe exited with exit code $($process.ExitCode)"

		if ($process.ExitCode -ne 0)
		{
			Write-Verbose "Microsoft Dynamics AX Setup failed on $hostName with exit code $($process.ExitCode). Inspect the setup logs at $logDir for details."
			throw "Microsoft Dynamics AX Setup failed on $hostName with exit code $($process.ExitCode). Inspect the setup logs at $logDir for details."
		}
	}
	catch [System.Exception]
	{
		Write-Verbose $_.Exception.Message
		throw
	}
}

function Run-Initialization
{
	param
	(
		[System.String]
		$licenseFile
	)

	try
	{
		$serviceName = 'AOS60$01'

		# verify that AOS is running
		Wait-AosIsRunning

		# Import license information
		Write-Verbose "Import license information"
		Run-LicenseInformation -licenseFile:$licenseFile
	}
	catch [System.Exception]
	{
		Write-Verbose $_.Exception.Message
		throw $_.Exception.Message
	}
}

function Run-ConfigurationFile
{
	param
	(
		[System.String]$configXml
	)

	#TODO: replace hardcoded path and configuration file
	Write-Verbose "Running configuration $configXml"
	$axClientDirectory = "C:\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\"
	$arguments ='-lazyclassloading -lazytableloading -StartupCmd=AutoRun_{0}' -f $configXml
	$process = (Start-Process Ax32.exe -WorkingDirectory $axClientDirectory -ArgumentList $arguments -Wait -PassThru)

	if (!$?)
	{
		Write-Verbose "Ax32.exe failed."
	}

	Write-Verbose "Ax32.exe exited with exit code $($process.ExitCode)."

	if ($process.ExitCode -ne 0)
	{
		Write-Verbose "Ax32.exe failed with exit code $($process.ExitCode)."

		throw "Ax32.exe failed with exit code $($process.ExitCode)."
	}
}

function Run-LicenseInformation
{
	param
	(
		[System.String]$licenseFile
	)

	$tempFile = Join-Path $env:SystemDrive -ChildPath temp
	$parmFileName = Join-Path $tempFile -ChildPath LicenseInformation.xml
	$logFileName = Join-Path $tempFile -ChildPath LicenseInformation.log

	Write-Verbose "Creating the CompileCILLicenseInformation.xml file at $parmFileName..."

	"<AxaptaAutoRun exitWhenDone=""true"" version=""6.3"" logFile=""$logFileName"">" > $parmFileName
	"    <LicenseInformation file=""$licenseFile"" />" >> $parmFileName
	"</AxaptaAutoRun>" >> $parmFileName

	Run-ConfigurationFile -configXml:$parmFileName
}

function Wait-AosIsRunning
{
	$serviceName = 'AOS60$01'
	$aosService = Get-Service -Name $serviceName

	while ($aosService.Status -ne "Running")
	{
		Start-Sleep -s 60
		$aosService = Get-Service -Name $serviceName
	}
}

function Restart-Aos
{
	param(
		[System.String]$computerName
	)

	Write-Verbose "Restarting AOS on machine $computerName"

	$session = New-PSSession -ComputerName $computerName
	Invoke-Command -Session $session -ScriptBlock { Restart-Service -Name 'AOS60$01' }
	Remove-PSSession -Session $session

	Write-Verbose "AOS restarted successfully"
}

Export-ModuleMember -Function *