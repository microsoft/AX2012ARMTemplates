#
# RDSConfiguration.ps1
#

configuration CommonSetup {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	Import-DSCResource -ModuleName xComputerManagement, xPSDesiredStateConfiguration

	Node localhost {

		xComputer DomainJoin {
			Name = $env:COMPUTERNAME
			DomainName = $domainName
			Credential = $adminCreds
		}

		Group AddToAdmin {
			DependsOn = "[xComputer]DomainJoin"
			GroupName = "Administrators"
			Ensure = "Present"
			MembersToInclude = "$($adminCreds.UserName)"
			Credential = $adminCreds
		}
	}
}

configuration DownloadAndInstallSqlServerNativeClient {

	param(
		[Parameter(Mandatory)]
		[String]$fileSqlServerNativeClientSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileSqlServerNativeClientSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSqlServerNativeClient {
			Uri = $fileSqlServerNativeClientSetupUri
			DestinationPath = $outputFile
		}

		Package InstallSqlServerNativeClient {
			DependsOn = "[xRemoteFile]DownloadSqlServerNativeClient"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft SQL Server 2012 Native Client "
			ProductId = "49D665A2-4C2A-476E-9AB8-FCC425F526FC"
			Arguments = "/qn IACCEPTSQLNCLILICENSETERMS=YES"
		}
	}
}

configuration DownloadAndInstallSQLSysClrTypes {

	param (
		[Parameter(Mandatory)]
		[String]$fileSqlSysClrTypesSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileSqlSysClrTypesSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLSysClrTypes {
			Uri = $fileSqlSysClrTypesSetupUri
			DestinationPath = $outputFile
		}

		Package InstallSQLSysClrTypes {
			DependsOn = "[xRemoteFile]DownloadSQLSysClrTypes"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft System CLR Types for SQL Server 2012 (x64)"
			ProductId = "F1949145-EB64-4DE7-9D81-E6D27937146C"
		}
	}
}

configuration DownloadAndInstallSQLSharedManagementObjects {

	param (
		[Parameter(Mandatory)]
		[String]$fileSqlSharedManagementObjectsSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileSqlSharedManagementObjectsSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLSharedManagementObjects {
			Uri = $fileSqlSharedManagementObjectsSetupUri
			DestinationPath = $outputFile
		}

		Package InstallSQLSharedManagementObjects {
			DependsOn = "[xRemoteFile]DownloadSQLSharedManagementObjects"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft SQL Server 2012 Management Objects  (x64)"
			ProductId = "FA0A244E-F3C2-4589-B42A-3D522DE79A42"
		}
	}
}

configuration ConfigureRDSLicense {
	
	param (
		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,
			
		[Parameter(Mandatory)]
		[String]$connectionBroker,

		[Parameter(Mandatory)]
		[String]$licenseServer
	)
	
	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost

	Node localhost {

		xRDServer AddLicenseServer {
			ConnectionBroker = $connectionBroker
            Server = $licenseServer
			Role = "RDS-Licensing"

			PsDscRunAsCredential = $adminCreds
        }

		xRDLicenseConfiguration LicenseConfiguration {
            ConnectionBroker = $connectionBroker
            LicenseServers = @( $licenseServer )
			LicenseMode = "PerUser"

			PsDscRunAsCredential = $adminCreds
        }
	}
}

configuration ConfigureRDSGateway {

	param (
		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$connectionBroker,

		[Parameter(Mandatory)]
		[String]$gatewayServer,

		[Parameter(Mandatory)]
        [String]$loadBalancerFqdn
	)
	
	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost
	Node localhost {

		xRDServer AddGatewayServer {
			ConnectionBroker = $connectionBroker
			Role = 'RDS-Gateway'
			Server = $gatewayServer
			GatewayExternalFqdn = $loadBalancerFqdn

			PsDscRunAsCredential = $adminCreds
		}

        xRDGatewayConfiguration GatewayConfiguration
        {
            DependsOn = "[xRDServer]AddGatewayServer"

            ConnectionBroker = $connectionBroker
            GatewayServer = $gatewayServer
            ExternalFqdn = $loadBalancerFqdn
            GatewayMode = "Custom"
            LogonMethod = "AllowUserToSelectDuringConnection"
            UseCachedCredentials = $true
            BypassLocal = $false

			PsDscRunAsCredential = $adminCreds
        } 
	}
}

configuration WindowsFeatures {
	
	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}

	Node localhost {

		WindowsFeature RDS-Web-Access {
			Ensure = "Present"
			Name = "RDS-Web-Access"
		}

		WindowsFeature RDS-Licensing {
			DependsOn = "[WindowsFeature]RDS-Web-Access"

			Ensure = "Present"
			Name = "RDS-Licensing"
		}

		WindowsFeature RDS-Gateway {
			DependsOn = "[WindowsFeature]RDS-Licensing"

			Ensure = "Present"
			Name = "RDS-Gateway"
		}

		WindowsFeature RSAT-RDS-Tools {
			DependsOn = "[WindowsFeature]RDS-Gateway"

			Ensure = "Present"
			Name = "RSAT-RDS-Tools"
			IncludeAllSubFeature = $true
		}
	}
}

configuration RDSMachine0 {

	param (
		[Parameter(Mandatory)]
        [String]$clientAccessName,

		[Parameter(Mandatory)]
		[Int]$clientNumberOfInstances,

		[Parameter(Mandatory)]
        [String]$clientVMNamePrefix,

		[Parameter(Mandatory)]
		[String]$connectionBrokerVMName,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$dynamicsInstallationCreds,

		[Parameter(Mandatory)]
        [String]$fileSqlServerNativeClientSetupUri,
		
		[Parameter(Mandatory)]
		[String]$fileSqlSharedManagementObjectsSetupUri,

		[Parameter(Mandatory)]
		[String]$fileSqlSysClrTypesSetupUri,

		[Parameter(Mandatory)]
        [String]$loadBalancerFqdn,

		[Parameter(Mandatory)]
		[String]$rdsCertificatePassword,

		[Parameter(Mandatory)]
		[String]$rdsIndex,

		[Parameter(Mandatory)]
		[Int]$rdsNumberOfInstances,

		[Parameter(Mandatory)]
		[String]$rdsStaticPrivateIpPrefix,

		[Parameter(Mandatory)]
		[Int]$rdsStaticPrivateIpValue
	)

	$shortDomain = $domainName.Split(".")[0]

	$localhost = "$env:COMPUTERNAME.$domainName"
	$connectionBrokerServer = "$connectionBrokerVMName.$domainName"
	$sessionHosts = @( 0..($clientNumberOfInstances-1) | % { "$clientVMNamePrefix$_.$domainName" } )
	$rdsCBIPAddresses = @(0..($rdsNumberOfInstances-1) | % { "$rdsStaticPrivateIpPrefix$($rdsStaticPrivateIpValue + $_)" } )
	$collectionName = "RemoteApps"
	$dynamicsAxClientFilePath = "$env:systemdrive\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\Ax32.exe"
	$dynamicsAxClientFileVirtualPath = "%SYSTEMDRIVE%\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\Ax32.exe"

	$databaseConnectionString = "DRIVER=SQL Server Native Client 11.0;SERVER=$dbSqlServer;Trusted_Connection=Yes;APP=Remote Desktop Services Connection Broker;Database=RemoteDesktopDeployment"
	$databaseFilePath = "F:\Data\RemoteDesktopDeployment.mdf"

	$validationKey = "6FAC2A1948E4AEE21AB629F9E54A50AB87E86AF95A92CE2E6FEAD632638280C0ABC7435358D12EAFF47919B65D247E546802163FBC26F19B50451D89D0B4A761,IsolateApps"
	$decryptionKey = "7BAF1B89C9B6AC637D6AB0A87D1177A03A405DD8391CA69B,IsolateApps"

	$loginName = "$shortDomain\$env:COMPUTERNAME`$"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost, xComputerManagement, xSQLServer, xDynamicsAX2012R3

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

		WindowsFeatures WindowsFeatures {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSqlServerNativeClient DownloadAndInstallSqlServerNativeClient {
			DependsOn = "[WindowsFeatures]WindowsFeatures"

			fileSqlServerNativeClientSetupUri = $fileSqlServerNativeClientSetupUri
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes {
			DependsOn = "[DownloadAndInstallSqlServerNativeClient]DownloadAndInstallSqlServerNativeClient"

			fileSqlSysClrTypesSetupUri = $fileSqlSysClrTypesSetupUri
		}

		DownloadAndInstallSQLSharedManagementObjects DownloadAndInstallSQLSharedManagementObjects {
			DependsOn = "[DownloadAndInstallSQLSysClrTypes]DownloadAndInstallSQLSysClrTypes"

			fileSqlSharedManagementObjectsSetupUri = $fileSqlSharedManagementObjectsSetupUri
		}

		xSQLServerLogin AddMachineUserToSqlServer {
			DependsOn = "[DownloadAndInstallSQLSharedManagementObjects]DownloadAndInstallSQLSharedManagementObjects"

			Ensure = "Present"
			Name = $loginName
			LoginType = "WindowsUser"
			SQLServer = $dbSqlServer
			ServerRoles = "dbcreator", "sysadmin"

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		xRDSessionDeployment Deployment {
			DependsOn = "[xSQLServerLogin]AddMachineUserToSqlServer"

			ConnectionBroker = $connectionBrokerServer
			WebAccessServer = $localhost
			SessionHosts = $sessionHosts

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		xRDWebAccessConfiguration WebAccessConfiguration {
			DependsOn = "[xRDSessionDeployment]Deployment"

			ValidationKey = $validationKey
			DecryptionKey = $decryptionKey

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		xRDConnectionBrokerHighAvailability ConnectionBrokerHighAvailability {
			DependsOn = "[xRDWebAccessConfiguration]WebAccessConfiguration"

			ConnectionBroker = $connectionBrokerServer
			ClientAccessName = $clientAccessName
			DatabaseConnectionString = $databaseConnectionString
			DatabaseFilePath = $databaseFilePath

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		ConfigureRDSLicense ConfigureRDSLicense {
			DependsOn = "[xRDConnectionBrokerHighAvailability]ConnectionBrokerHighAvailability"

			adminCreds = $dynamicsInstallationCreds
			connectionBroker = $connectionBrokerServer
			licenseServer = $localhost
		}

		ConfigureRDSGateway ConfigureRDSGateway {
			DependsOn = "[ConfigureRDSLicense]ConfigureRDSLicense"

			adminCreds = $dynamicsInstallationCreds
			connectionBroker = $connectionBrokerServer
			gatewayServer = $localhost
			loadBalancerFqdn = $loadBalancerFqdn
		}

		xRDSessionCollection Collection {
			DependsOn = "[ConfigureRDSGateway]ConfigureRDSGateway"

			ConnectionBroker = $connectionBrokerServer
			CollectionName = $collectionName
			CollectionDescription = "Remote applications collection"
			SessionHosts = $sessionHosts

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		xRDRemoteApp RemoteApp {
			DependsOn = "[xRDSessionCollection]Collection"
			
			Alias = "ax32"
			CollectionName = $collectionName
			DisplayName = "Microsoft Dynamics AX 2012"
			FilePath = $dynamicsAxClientFilePath
			FileVirtualPath = $dynamicsAxClientFileVirtualPath
			CommandLineSetting = "DoNotAllow"
			IconPath = $dynamicsAxClientFileVirtualPath
			ShowInWebAccess = $true

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		if ($rdsIndex -eq ($rdsNumberOfInstances - 1))
		{
			xRDCertificate RDCertificate {
				DependsOn = "[xRDRemoteApp]RemoteApp"

				ConnectionBroker = $connectionBrokerServer
				Password = $rdsCertificatePassword
				DnsName = $loadBalancerFqdn

				PsDscRunAsCredential = $dynamicsInstallationCreds
			}
		}
	}
}

configuration RDSMachine1N {

	param (
		[Parameter(Mandatory)]
		[String]$connectionBrokerVMName,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$dynamicsInstallationCreds,

		[Parameter(Mandatory)]
        [String]$fileSqlServerNativeClientSetupUri,

		[Parameter(Mandatory)]
		[String]$fileSqlSharedManagementObjectsSetupUri,

		[Parameter(Mandatory)]
		[String]$fileSqlSysClrTypesSetupUri,

		[Parameter(Mandatory)]
        [String]$loadBalancerFqdn,

		[Parameter(Mandatory)]
		[String]$rdsCertificatePassword,

		[Parameter(Mandatory)]
		[String]$rdsIndex,

		[Parameter(Mandatory)]
		[Int]$rdsNumberOfInstances,

		[Parameter(Mandatory)]
		[String]$rdsStaticPrivateIpPrefix,

		[Parameter(Mandatory)]
		[Int]$rdsStaticPrivateIpValue
	)

	$shortDomain = $domainName.Split(".")[0]

	$localhost = "$env:COMPUTERNAME.$domainName"
	$connectionBrokerServer = "$connectionBrokerVMName.$domainName"

	$rdsCBIPAddresses = @(0..($rdsNumberOfInstances-1) | % { "$rdsStaticPrivateIpPrefix$($rdsStaticPrivateIpValue + $_)" } )

	$validationKey = "6FAC2A1948E4AEE21AB629F9E54A50AB87E86AF95A92CE2E6FEAD632638280C0ABC7435358D12EAFF47919B65D247E546802163FBC26F19B50451D89D0B4A761,IsolateApps"
	$decryptionKey = "7BAF1B89C9B6AC637D6AB0A87D1177A03A405DD8391CA69B,IsolateApps"
	
	$loginName = "$shortDomain\$env:COMPUTERNAME`$"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost, xComputerManagement, xSQLServer, xDynamicsAX2012R3

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

		WindowsFeatures WindowsFeatures {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSqlServerNativeClient DownloadAndInstallSqlServerNativeClient {
			DependsOn = "[WindowsFeatures]WindowsFeatures"

			fileSqlServerNativeClientSetupUri = $fileSqlServerNativeClientSetupUri
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes {
			DependsOn = "[DownloadAndInstallSqlServerNativeClient]DownloadAndInstallSqlServerNativeClient"

			fileSqlSysClrTypesSetupUri = $fileSqlSysClrTypesSetupUri
		}

		DownloadAndInstallSQLSharedManagementObjects DownloadAndInstallSQLSharedManagementObjects {
			DependsOn = "[DownloadAndInstallSQLSysClrTypes]DownloadAndInstallSQLSysClrTypes"

			fileSqlSharedManagementObjectsSetupUri = $fileSqlSharedManagementObjectsSetupUri
		}

		xSQLServerLogin AddMachineUserToSqlServer {
			DependsOn = "[DownloadAndInstallSQLSharedManagementObjects]DownloadAndInstallSQLSharedManagementObjects"

			Ensure = "Present"
			Name = $loginName
			LoginType = "WindowsUser"
			SQLServer = $dbSqlServer
			ServerRoles = "dbcreator", "sysadmin"

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		xRDServer AddConnectionBroker {
			DependsOn = "[xSQLServerLogin]AddMachineUserToSqlServer"

			ConnectionBroker = $connectionBrokerServer
            Server = $localhost
			Role = "RDS-Connection-Broker"

			PsDscRunAsCredential = $dynamicsInstallationCreds
        }

		xRDServer AddWebAccess {
			DependsOn = "[xRDServer]AddConnectionBroker"

			ConnectionBroker = $connectionBrokerServer
            Server = $localhost
			Role = "RDS-Web-Access"

			PsDscRunAsCredential = $dynamicsInstallationCreds
        }

		xRDWebAccessConfiguration WebAccessConfiguration {
			DependsOn = "[xRDServer]AddWebAccess"

			ValidationKey = $validationKey
			DecryptionKey = $decryptionKey

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}

		ConfigureRDSLicense ConfigureRDSLicense {
			DependsOn = "[xRDWebAccessConfiguration]WebAccessConfiguration"

			adminCreds = $dynamicsInstallationCreds
			connectionBroker = $connectionBrokerServer
			licenseServer = $localhost
		}

		ConfigureRDSGateway ConfigureRDSGateway {
			DependsOn = "[ConfigureRDSLicense]ConfigureRDSLicense"

			adminCreds = $dynamicsInstallationCreds
			connectionBroker = $connectionBrokerServer
			gatewayServer = $localhost
			loadBalancerFqdn = $loadBalancerFqdn
		}

		if ($rdsIndex -eq ($rdsNumberOfInstances - 1))
		{
			xRDCertificate RDCertificate {
				DependsOn = "[ConfigureRDSGateway]ConfigureRDSGateway"

				ConnectionBroker = $connectionBrokerServer
				Password = $rdsCertificatePassword
				DnsName = $loadBalancerFqdn

				PsDscRunAsCredential = $dynamicsInstallationCreds
			}
		}
	}
}