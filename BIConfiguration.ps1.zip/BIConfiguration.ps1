#
# BIConfiguration.ps1
#

configuration CommonSetup {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	Import-DSCResource -ModuleName xComputerManagement, xPSDesiredStateConfiguration

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		xComputer DomainJoin {
			Name = $env:COMPUTERNAME
			DomainName = $domainName
			Credential = $adminCreds
		}

		Group AddToAdmin {
			DependsOn = "[xComputer]DomainJoin"
			GroupName = "Administrators"
			Ensure = "Present"
			MembersToInclude = "$($adminCreds.UserName)"
			Credential = $adminCreds
		}
	}
}

configuration DownloadAXSetup {
	
	param (
		[Parameter(Mandatory)]
		[String]$fileAxSetupUri
	)

	$regex = ".+\/(.+)"
	$fileName = $fileAxSetupUri -replace $regex, '$1'
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath $fileName

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	Node localhost {

		xRemoteFile AXSetup {
			Uri = $fileAxSetupUri
			DestinationPath = $outputFile
		}

		xZipExtract ExtractAXSetup {
			DependsOn = "[xRemoteFile]AXSetup"

			SourceFile = $outputFile
			Destination = $outputPath
		}
	}
}

configuration PrepareUpdatesAndHotFixes {
	
	param (
		[Parameter(Mandatory)]
		[String]$fileAxSetupUpdatesPath,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$updatesPath = Join-Path $extractedPath -ChildPath Updates

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	$regex = ".+\/(.+)"

	Node localhost {

		$counter = 0

		foreach($package in $cumulativeUpdatesAndHotFixes)
		{
			$fileName = $package -replace $regex, '$1'
			$fileName = Join-Path $updatesPath -ChildPath $fileName

			$remoteFileResource = "RemoteFile$counter"
			$zipExtractResource = "ZipExtract$counter"

			xRemoteFile $remoteFileResource {
			Uri = $package
			DestinationPath = $fileName
			}

			xZipExtract $zipExtractResource {
				DependsOn = "[xRemoteFile]$remoteFileResource"

				SourceFile = $fileName
				Destination = $updatesPath
			}

			$counter++
		}
	}
}

configuration BIMachine {

	param (
		[Parameter(Mandatory)]
		[String]$aosServer,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[Parameter(Mandatory)]
		[String]$bcProxyAccount,

		[Parameter(Mandatory)]
		[String]$bcProxyAccountPassword,
		
		[String[]]$cumulativeUpdatesAndHotFixes,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$dynamicsInstallationCreds,

		[Parameter(Mandatory)]
		[String]$fileAxSetupPath,

		[Parameter(Mandatory)]
		[String]$fileAxSetupUpdatesPath,

		[Parameter(Mandatory)]
		[String]$fileAxSetupUri,

		[Parameter(Mandatory)]
		[Boolean]$restartAOS
	)

	$shortDomain = $domainName.Split(".")[0]

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$setupFile = Join-Path $outputPath -ChildPath $fileAxSetupPath

	$localhost = $env:COMPUTERNAME
	$localhostFqdn = "$localhost.$domainName"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xCredSSP, xSqlServer, xDynamicsAX2012R3

	Node localhost {

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $dynamicsInstallationCreds
		}

		xSqlServerSysAdmin SqlServerSysAdmin {
			DependsOn = "[CommonSetup]CommonSetup"

			ServerFqdn = $localhostFqdn
			Username = "$($dynamicsInstallationCreds.UserName)"
		}

		xSqlServerSysAdmin ReportServer {
			DependsOn = "[xSqlServerSysAdmin]SqlServerSysAdmin"

			ServerFqdn = $localhostFqdn
			Username = "NT SERVICE\ReportServer"
		}

		xCredSSP Server {
            DependsOn = "[xSqlServerSysAdmin]ReportServer"
			
			Ensure = "Present"
            Role = "Server"
        }

		xCredSSP Client {
			DependsOn = "[xCredSSP]Server"

            Ensure = "Present"
            Role = "Client"
            DelegateComputers = $localhostFqdn
        }

		xSqlServerFirewall ReportingServices {
			DependsOn = "[xCredSSP]Client"
			
			Ensure = "Present"
            SourcePath = $env:SystemDrive
            SourceFolder = "\SQLServer_12.0_Full"
            Features= "RS"
            InstanceName = "MSSQLSERVER"
		}

		xSqlServerRSConfig SqlServerRSConfig {
			DependsOn = "[xSqlServerFirewall]ReportingServices"

			InstanceName = "MSSQLSERVER"
			RSSQLServer = $localhost
			RSSQLInstanceName = "MSSQLSERVER"
			SQLAdminCredential = $dynamicsInstallationCreds
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[xSqlServerRSConfig]SqlServerRSConfig"

			FileAxSetupUri = $fileAxSetupUri
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			fileAxSetupUpdatesPath = $fileAxSetupUpdatesPath
			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsReportingAndAnalysis DynamicsReportingAndAnalysis {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			aosServer = $aosServer
			dbSqlServer = $dbSqlServer
			dbSqlServerDatabase = $dbSqlServerDatabase
			aosWsdlPort = $aosWsdlPort
			bcProxyAccount = $bcProxyAccount
			bcProxyAccountPassword = $bcProxyAccountPassword
			setupFile = $setupFile
			Ensure = "Present"
			RestartAOS = $restartAOS
			DeployReports = $true

			PsDscRunAsCredential = $dynamicsInstallationCreds
		}
	}
}