#
# Configuration.ps1
#

configuration CommonSetup {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)

	Import-DSCResource -ModuleName xComputerManagement, xPSDesiredStateConfiguration

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		xComputer DomainJoin {
			Name = $env:COMPUTERNAME
			DomainName = $domainName
			Credential = $domainCreds
		}

		Group AddToAdmin {
			DependsOn = "[xComputer]DomainJoin"
			GroupName = "Administrators"
			Ensure = "Present"
			MembersToInclude = "$domainName\$($adminCreds.UserName)"
			Credential = $domainCreds
		}
	}
}

configuration DownloadAXSetup {
	
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputAXSetupFile =  [io.path]::Combine($outputPath, '6.3.164.0.zip')
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	Node localhost {

		xRemoteFile AXSetup {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/6.3.164.0.zip"
			DestinationPath = $outputAXSetupFile
		}

		xZipExtract ExtractAXSetup {
			DependsOn = "[xRemoteFile]AXSetup"

			SourceFile = $outputAXSetupFile
			Destination = $outputPath
		}
	}
}

configuration PrepareUpdatesAndHotFixes {
	param (
		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$updatesPath = Join-Path $extractedPath -ChildPath Updates

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration, xDynamicsAX2012R3

	$regex = ".+\/(.+)"

	Node localhost {

		$counter = 0

		foreach($package in $cumulativeUpdatesAndHotFixes)
		{
			$fileName = $package -replace $regex, '$1'
			$fileName = Join-Path $updatesPath -ChildPath $fileName

			$remoteFileResource = "RemoteFile$counter"
			$zipExtractResource = "ZipExtract$counter"

			xRemoteFile $remoteFileResource {
			Uri = $package
			DestinationPath = $fileName
			}

			xZipExtract $zipExtractResource {
				DependsOn = "[xRemoteFile]$remoteFileResource"

				SourceFile = $fileName
				Destination = $updatesPath
			}

			$counter++
		}
	}
}

configuration DownloadAndInstallMSChart {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath MSChart.exe

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadMSChart {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/MSChart.exe"
			DestinationPath = $outputFile
		}

		Package InstallMSChart {
			DependsOn = "[xRemoteFile]DownloadMSChart"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft Chart Controls for Microsoft .NET Framework 3.5"
			ProductId = "41785C66-90F2-40CE-8CB5-1C94BFC97280"
			Arguments = "/q"
		}
	}
}

configuration DownloadAndInstallSQLSysClrTypes {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath SQLSysClrTypes.msi

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLSysClrTypes {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/SQLSysClrTypes.msi"
			DestinationPath = $outputFile
		}

		Package InstallSQLSysClrTypes {
			DependsOn = "[xRemoteFile]DownloadSQLSysClrTypes"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft System CLR Types for SQL Server 2012 (x64)"
			ProductId = "F1949145-EB64-4DE7-9D81-E6D27937146C"
		}
	}
}

configuration DownloadAndInstallSQLAMO {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath SQLSERVER2008_ASAMO10.msi

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLAMO {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/SQLSERVER2008_ASAMO10.msi"
			DestinationPath = $outputFile
		}

		Package InstallSQLAMO {
			DependsOn = "[xRemoteFile]DownloadSQLAMO"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft SQL Server 2008 Analysis Management Objects"
			ProductId = "A2C487D8-EA61-4083-B589-58BED96C7D45"
		}
	}
}

configuration DownloadAndInstallSQLADOMD {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath SQLSERVER2008_ASADOMD10.msi

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSQLADOMD {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/SQLSERVER2008_ASADOMD10.msi"
			DestinationPath = $outputFile
		}

		Package InstallSQLADOMD {
			DependsOn = "[xRemoteFile]DownloadSQLADOMD"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft SQL Server 2008 R2 ADOMD.NET"
			ProductId = "DE81CA12-BA88-4D4F-BAF2-12DD94A9EF35"
		}
	}
}

configuration DownloadAndInstallReportViewer {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath ReportViewer.msi

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadReportViewer {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/ReportViewer.msi"
			DestinationPath = $outputFile
		}

		Package InstallReportViewer {
			DependsOn = "[xRemoteFile]DownloadReportViewer"

			Ensure = "Present"
			Path = $outputFile
			Name = "Microsoft Report Viewer 2012 Runtime"
			ProductId = "C58378BC-0B7B-474E-855C-9D02E5E75D71"
		}
	}
}

configuration DownloadAndInstallSharePointUpdate {
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath ubersrvsp2013-kb2767999-fullfile-x64-glb.exe
	$logFile = Join-Path $outputPath -ChildPath spupdate.log

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile DownloadSharePointUpdate {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/ubersrvsp2013-kb2767999-fullfile-x64-glb.exe"
			DestinationPath = $outputFile
		}

		Package InstallSharePointUpdate {
			DependsOn = "[xRemoteFile]DownloadSharePointUpdate"

			Ensure = "Present"
			Path = $outputFile
			Name = "Update for Microsoft SharePoint Enterprise Server 2013 (KB2767999) 64-Bit Edition"
			ProductId = ""
			Arguments = "/quiet /passive /forcerestart /log:$logFile"
		}
	}
}

configuration DownloadAxaptaAutoRunConfiguration {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath AxaptaAutoRunConfiguration.xml

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile AxaptaAutoRunConfiguration {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/AxaptaAutoRunConfiguration.xml"
			DestinationPath = $outputFile
		}
	}
}

configuration DownloadAxLicenseFile {

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$outputFile = Join-Path $outputPath -ChildPath demolicense60_31122016.txt

	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node localhost {

		xRemoteFile LicenseFile {
			Uri = "https://axinmarketstorage.blob.core.windows.net/armdeploy/demolicense60_31122016.txt"
			DestinationPath = $outputFile
		}
	}
}

configuration InstallRDS {

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		WindowsFeature RDS-Connection-Broker {
			Ensure = "Present"
			Name = "RDS-Connection-Broker"
		}

		WindowsFeature RDS-Web-Access {
			Ensure = "Present"
			Name = "RDS-Web-Access"
		}

		WindowsFeature RSAT-RDS-Tools {
			Ensure = "Present"
			Name = "RSAT-RDS-Tools"
			IncludeAllSubFeature = $true
		}

		WindowsFeature RDS-Licensing {
			Ensure = "Present"
			Name = "RDS-Licensing"
		}

		WindowsFeature RDS-Gateway {
			Ensure = "Present"
			Name = "RDS-Gateway"
		}
	}
}

configuration ConfigureRDSLicense {
	
	param (
		[Parameter(Mandatory)]
		[String]$domainName,
		
		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$localhost = "$env:COMPUTERNAME.$domainName"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost

	Node localhost {

		xRDServer AddLicenseServer {
            Server = $localhost
			Role = "RDS-Licensing"

			PsDscRunAsCredential = $domainCreds
        }

        xRDLicenseConfiguration LicenseConfiguration {
            ConnectionBroker = $localhost
            LicenseServers = @( $localhost )
			LicenseMode = "PerUser"

			PsDscRunAsCredential = $domainCreds
        }
	}
}

configuration ConfigureRDSGateway {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,
		
		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$gatewayServer,

		[Parameter(Mandatory)]
        [String]$loadBalancerFqdn
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$localhost = "$env:COMPUTERNAME.$domainName"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost

	Node localhost {

		xRDServer AddGatewayServer {
			Role = "RDS-Gateway"
			Server = $gatewayServer
			GatewayExternalFqdn = $loadBalancerFqdn

			PsDscRunAsCredential = $domainCreds
		}

        xRDGatewayConfiguration GatewayConfiguration
        {
            DependsOn = "[xRDServer]AddGatewayServer"

            ConnectionBroker = $localhost
            GatewayServer = $gatewayServer
            ExternalFqdn = $loadBalancerFqdn
            GatewayMode = "Custom"
            LogonMethod = "AllowUserToSelectDuringConnection"
            UseCachedCredentials = $true
            BypassLocal = $false

			PsDscRunAsCredential = $domainCreds
        } 
	}
}

configuration AOSMachine0 {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

		[Parameter(Mandatory)]
		[String]$aosInstanceName,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[Parameter(Mandatory)]
		[String]$aosAccount,

		[Parameter(Mandatory)]
		[String]$aosAccountPassword,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe
	$licenseFile = Join-Path $outputPath -ChildPath demolicense60_31122016.txt

	$localhost = $env:COMPUTERNAME
	$localhostFqdn = "$localhost.$domainName"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xDynamicsAX2012R3

	Node localhost {

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		WindowsFeature NET-Framework-Core {
			Ensure = "Present"
			Name = "NET-Framework-Core"
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		DownloadAndInstallMSChart DownloadAndInstallMSChart {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLAMO DownloadAndInstallSQLAMO{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLADOMD DownloadAndInstallSQLADOMD{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallReportViewer DownloadAndInstallReportViewer{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAxLicenseFile DownloadAxLicenseFile{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		xDynamicsAOS DynamicsAOS {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			dbSqlServer = $dbSqlServer
			dbSqlServerDatabase = $dbSqlServerDatabase
			aosInstanceName = $aosInstanceName
			aosWsdlPort = $aosWsdlPort
			aosAccount = $aosAccount
			aosAccountPassword = $aosAccountPassword
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}

		xDynamicsClient DynamicsClient {

			Ensure = "Present"
			aosServer = $env:COMPUTERNAME
			aosWsdlPort = $aosWsdlPort
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}

		xDynamicsInitialization DynamicsInitialization {
			LicenseFile = $licenseFile

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration AOSMachine1N {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

		[Parameter(Mandatory)]
		[String]$aosInstanceName,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[Parameter(Mandatory)]
		[String]$aosAccount,

		[Parameter(Mandatory)]
		[String]$aosAccountPassword,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xDynamicsAX2012R3

	Node localhost {

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		WindowsFeature NET-Framework-Core {
			Ensure = "Present"
			Name = "NET-Framework-Core"
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		DownloadAndInstallMSChart DownloadAndInstallMSChart {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLAMO DownloadAndInstallSQLAMO{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLADOMD DownloadAndInstallSQLADOMD{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		xDynamicsAOS DynamicsAOS {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			dbSqlServer = $dbSqlServer
			dbSqlServerDatabase = $dbSqlServerDatabase
			aosInstanceName = $aosInstanceName
			aosWsdlPort = $aosWsdlPort
			aosAccount = $aosAccount
			aosAccountPassword = $aosAccountPassword
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration SQLWitnessMachine {
	param
    (
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

        [Parameter(Mandatory)]
        [String]$sharePath,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xSmbShare, cDisk, xDisk, xActiveDirectory
    
    Node localhost
    {
		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        File FSWFolder
        {
			DependsOn = "[CommonSetup]CommonSetup"

            DestinationPath = "F:\$($sharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
        }

        xSmbShare FSWShare
        {
            Name = $sharePath.ToUpperInvariant()
            Path = "F:\$($sharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators"
            Ensure = "Present"
            DependsOn = "[File]FSWFolder"
        }
    }
}

configuration SQLAlwaysOnPrepare {
	
	param
    (
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

		[Parameter(Mandatory)]
        [PSCredential]$localAdminCreds,

		[Parameter(Mandatory)]
        [PSCredential]$sqlServiceCreds,

		[Parameter(Mandatory)]
        [String]$SqlAlwaysOnEndpointName,

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    )

    Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xActiveDirectory, cDisk, xDisk, xSQL, xSQLServer, xSqlPs, xNetworking
    
	$shortDomain = $domainName.Split(".")[0]

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$shortDomain\$($adminCreds.UserName)", $adminCreds.Password)
    $domainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
    $sqlCreds = New-Object System.Management.Automation.PSCredential ("$shortDomain\$($sqlServiceCreds.UserName)", $sqlServiceCreds.Password)
    
	$localCreds = New-Object System.Management.Automation.PSCredential ("$env:COMPUTERNAME\$($localAdminCreds.UserName)", $localAdminCreds.Password)

    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        xWaitforDisk Disk3
        {
             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart LogDisk
        {
            DiskNumber = 3
            DriveLetter = "G"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

        xFirewall DatabaseEngineFirewallRule
        {
			Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            Action = "Allow"
            LocalPort = "1433"
        }

        xFirewall DatabaseMirroringFirewallRule
        {
			Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
            Enabled = "True"
			Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            Action = "Allow"
            LocalPort = "5022"
        }

        xFirewall ListenerFirewallRule
        {
			Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            Action = "Allow"
            LocalPort = "59999"
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $domainCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $localCreds
        }

   #     xADUser CreateSqlServerServiceAccount
   #     {
			#DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"

   #         DomainAdministratorCredential = $domainCreds
   #         DomainName = $domainName
   #         UserName = $sqlCreds.UserName
   #         Password = $sqlCreds
   #         Ensure = "Present"

			#PsDscRunAsCredential = $domainCreds
   #     }

   #     xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
   #     {
			#DependsOn = "[xADUser]CreateSqlServerServiceAccount"

   #         Name = $sqlCreds.UserName
   #         LoginType = "WindowsUser"
   #         ServerRoles = "sysadmin"
   #         Enabled = $true
   #         Credential = $localCreds
   #     }

        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
			DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"

            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $domainCreds
            ServiceCredential = $domainCreds
            MaxDegreeOfParallelism = 1
            FilePath = "F:\DATA"
            LogPath = "G:\LOG"
            DomainAdministratorCredential = $DomainFQDNCreds
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }
    }
}

configuration SQLAlwaysOnCreateCluster {

	param
    (
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

		[Parameter(Mandatory)]
        [PSCredential]$localAdminCreds,

        [Parameter(Mandatory)]
        [PSCredential]$sqlServiceCreds,

        [Parameter(Mandatory)]
        [String]$clusterName,

        [Parameter(Mandatory)]
        [String]$sharePath,

        [Parameter(Mandatory)]
        [String[]]$nodes,

        [Parameter(Mandatory)]
        [String]$sqlAlwaysOnAvailabilityGroupName,

        [Parameter(Mandatory)]
        [String]$sqlAlwaysOnAvailabilityGroupListenerName,

        [Parameter(Mandatory)]
        [String]$lbName,

        [Parameter(Mandatory)]
        [String]$lbAddress,
		
        [Parameter(Mandatory)]
        [String]$primaryReplica,

        [Parameter(Mandatory)]
        [String]$secondaryReplica,

        [Parameter(Mandatory)]
        [String]$sqlAlwaysOnEndpointName,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

		[String[]]$cumulativeUpdatesAndHotFixes,

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    )

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xActiveDirectory, cDisk, xDisk, xSQL, xSQLServer, xSqlPs, xNetworking, xFailOverCluster, xCredSSP, xDynamicsAX2012R3

	$shortDomain = $domainName.Split(".")[0]
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$shortDomain\$($adminCreds.UserName)", $adminCreds.Password)
    $domainFQDNCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($Admincreds.UserName)", $adminCreds.Password)
    $sqlCreds = New-Object System.Management.Automation.PSCredential ("$shortDomain\$($sqlServiceCreds.UserName)", $sqlServiceCreds.Password)
    
	$localCreds = New-Object System.Management.Automation.PSCredential ("$env:COMPUTERNAME\$($localAdminCreds.UserName)", $localAdminCreds.Password)

	$lbFQName="$lbName.$domainName"

	$localhost = $env:COMPUTERNAME
	$localhostFqdn = "$localhost.$domainName"

	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe

    Node localhost
    {
		xCredSSP Server {
            Ensure = "Present"
            Role = "Server"
        }

		xCredSSP Client {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = $localhostFqdn
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        xWaitforDisk Disk3
        {
             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart LogDisk
        {
            DiskNumber = 3
            DriveLetter = "G"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
        
		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

        xCluster FailoverCluster
        {
            Name = $clusterName
            DomainAdministratorCredential = $domainCreds
            Nodes = $nodes
        }

        xWaitForFileShareWitness WaitForFSW
        {
            SharePath = $sharePath
            DomainAdministratorCredential = $domainCreds
        }

        xClusterQuorum FailoverClusterQuorum
        {
            Name = $clusterName
            SharePath = $sharePath
            DomainAdministratorCredential = $domainCreds
        }

        Script DisableStorageClustering
        {
            SetScript =  "Get-StorageSubsystem -FriendlyName 'Clustered Storage Spaces*' | Set-StorageSubSystem -AutomaticClusteringEnabled `$False"
            TestScript = "!(Get-StorageSubsystem -FriendlyName 'Clustered Storage Spaces*').AutomaticClusteringEnabled"
            GetScript = "@{Ensure = if (!(Get-StorageSubsystem -FriendlyName 'Clustered Storage Spaces*').AutomaticClusteringEnabled) {'Present'} else {'Absent'}}"
            DependsOn = "[xClusterQuorum]FailoverClusterQuorum"
        }

        Script IncreaseClusterTimeouts
        {
            SetScript = "(Get-Cluster).SameSubnetDelay = 2000; (Get-Cluster).SameSubnetThreshold = 15; (Get-Cluster).CrossSubnetDelay = 3000; (Get-Cluster).CrossSubnetThreshold = 15"
            TestScript = "(Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15"
            GetScript = "@{Ensure = if ((Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15) {'Present'} else {'Absent'}}"
            DependsOn = "[Script]DisableStorageClustering"
        }

        xFirewall DatabaseEngineFirewallRule
        {
			Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            Action = "Allow"
            LocalPort = "1433"
        }

        xFirewall DatabaseMirroringFirewallRule
        {
			Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            Action = "Allow"
            LocalPort = "5022"
        }

        xFirewall ListenerFirewallRule
        {
			Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
			Group = "SQL Server"
			Ensure = "Present"
			Enabled = "True"
            Direction = "Inbound"
			Protocol = "TCP"
			Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            Action = "Allow"
            LocalPort = "59999"
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $domainCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $localCreds
        }

   #     xADUser CreateSqlServerServiceAccount
   #     {
			#DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"

   #         DomainAdministratorCredential = $domainCreds
   #         DomainName = $domainName
   #         UserName = $sqlServiceCreds.UserName
   #         Password = $sqlServiceCreds
   #         Ensure = "Present"
   #     }

   #     xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
   #     {
			#DependsOn = "[xADUser]CreateSqlServerServiceAccount"

   #         Name = $SQLCreds.UserName
   #         LoginType = "WindowsUser"
   #         ServerRoles = "sysadmin"
   #         Enabled = $true
   #         Credential = $adminCreds
   #     }

        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
			DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"

            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $domainCreds
            ServiceCredential = $domainCreds
            Hadr = "Enabled"
            MaxDegreeOfParallelism = 1
            FilePath = "F:\DATA"
            LogPath = "G:\LOG"
            DomainAdministratorCredential = $DomainFQDNCreds
        }

        xSqlEndpoint SqlAlwaysOnEndpoint
        {
			DependsOn = "[xSqlServer]ConfigureSqlServerWithAlwaysOn"

            InstanceName = $env:COMPUTERNAME
            Name = $sqlAlwaysOnEndpointName
            PortNumber = 5022
            AllowedUser = $domainCreds.UserName
            SqlAdministratorCredential = $domainCreds
        }

        xSqlServer ConfigureSqlServerSecondaryWithAlwaysOn
        {
			DependsOn = "[xSqlEndPoint]SqlAlwaysOnEndpoint"

            InstanceName = $secondaryReplica
            SqlAdministratorCredential = $domainCreds
            Hadr = "Enabled"
            DomainAdministratorCredential = $DomainFQDNCreds
        }

        xSqlEndpoint SqlSecondaryAlwaysOnEndpoint
        {
			DependsOn = "[xSqlServer]ConfigureSqlServerSecondaryWithAlwaysOn"

            InstanceName = $secondaryReplica
            Name = $sqlAlwaysOnEndpointName
            PortNumber = 5022
            AllowedUser = $domainCreds.UserName
            SqlAdministratorCredential = $domainCreds
        }

        xSqlAvailabilityGroup SqlAG
        {
			DependsOn = "[xSqlEndpoint]SqlSecondaryAlwaysOnEndpoint"

            Name = $sqlAlwaysOnAvailabilityGroupName
            ClusterName = $clusterName
            InstanceName = $env:COMPUTERNAME
            PortNumber = 5022
            DomainCredential =$domainCreds
            SqlAdministratorCredential = $domainCreds
        }

        xSqlAvailabilityGroupListener SqlAGListener
        {
			DependsOn = "[xSqlAvailabilityGroup]SqlAG"

            Name = $sqlAlwaysOnAvailabilityGroupListenerName
            AvailabilityGroupName = $sqlAlwaysOnAvailabilityGroupName
            DomainNameFqdn = $lbFQName
            LBAddress=$lbAddress
            ListenerPortNumber = 1433
            ProbePortNumber = 59999
            InstanceName = $env:COMPUTERNAME
            DomainCredential =$domainCreds
            SqlAdministratorCredential = $domainCreds
        }

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsDatabase DynamicsDatabase {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			dbSqlServer = "localhost"
			dbSqlServerDatabase = $dbSqlServerDatabase
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}

		xSqlNewAGDatabase SQLAGDatabases
        {
            SqlAlwaysOnAvailabilityGroupName = $SqlAlwaysOnAvailabilityGroupName
            DatabaseNames = $dbSqlServerDatabase
            PrimaryReplica = $PrimaryReplica
            SecondaryReplica = $SecondaryReplica
            SqlAdministratorCredential = $domainCreds
            DependsOn = "[xSqlAvailabilityGroupListener]SqlAGListener"
        }

        xSqlTestAGDatabase SQLAGDatabasesVerification
        {
            SqlAlwaysOnAvailabilityGroupName = $SqlAlwaysOnAvailabilityGroupName
            InstanceName = $env:COMPUTERNAME
            DomainCredential =$DomainCreds
            DependsOn = "[xSqlNewAGDatabase]SQLAGDatabases"
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $True
        }
	}
}

configuration SQLMachine {

		param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[PSCredential]$localAdminCreds,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$shortDomain = $domainName.Split(".")[0]
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe
	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$machineCreds = New-Object System.Management.Automation.PSCredential ("$env:COMPUTERNAME\$($localAdminCreds.UserName)", $localAdminCreds.Password)
	$localhost = $env:COMPUTERNAME
	$localhostFqdn = "$localhost.$domainName"
	$userName = "$shortDomain\$($adminCreds.UserName)"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xSqlServer, xDynamicsAX2012R3

	Node localhost {

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		xSqlServerSysAdmin SqlServerSysAdmin {
			DependsOn = "[CommonSetup]CommonSetup"

			ServerFqdn = $localhostFqdn
			Username = $userName
		}

		xSqlServerFirewall DatabaseEngine {
			DependsOn = "[CommonSetup]CommonSetup"
			
			Ensure = "Present"
            SourcePath = $env:SystemDrive
            SourceFolder = "\SQLServer_12.0_Full"
            Features= "SQLENGINE"
            InstanceName = "MSSQLSERVER"
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsDatabase DynamicsDatabase {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			dbSqlServer = "localhost"
			dbSqlServerDatabase = $dbSqlServerDatabase
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration ClientMachine {
	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$aosServer,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost, xComputerManagement, xDynamicsAX2012R3

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		WindowsFeature NET-Framework-Core {
			Ensure = "Present"
			Name = "NET-Framework-Core"
		}

		WindowsFeature RDS-RD-Server {
			Ensure = "Present"
			Name = "RDS-RD-Server"
		}

		DownloadAndInstallMSChart DownloadAndInstallMSChart {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLAMO DownloadAndInstallSQLAMO {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLADOMD DownloadAndInstallSQLADOMD {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallReportViewer DownloadAndInstallReportViewer {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsClient DynamicsClient {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			aosServer = $aosServer
			aosWsdlPort = $aosWsdlPort
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration RDSGatewayMachine {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds
	)

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		WindowsFeature RDS-Gateway {
			Ensure = "Present"
			Name = "RDS-Gateway"
		}

		WindowsFeature RDS-Web-Access {
			Ensure = "Present"
			Name = "RDS-Web-Access"
		}
	}
}

configuration RDSCBMachine {
	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[String]$gatewayVMName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[Int]$clientNumberOfInstances,

		[Parameter(Mandatory)]
        [String]$clientVMNamePrefix,

		[Parameter(Mandatory)]
        [String]$loadBalancerFqdn
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$localhost = "$env:COMPUTERNAME.$domainName"
	$gatewayServer = "$gatewayVMName.$domainName"
	$sessionHosts = @( 0..($clientNumberOfInstances-1) | % { "$clientVMNamePrefix$_.$domainName" } )
	$collectionName = "RemoteApps"
	$dynamicsAxClientFilePath = "$env:systemdrive\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\Ax32.exe"
	$dynamicsAxClientFileVirtualPath = "%SYSTEMDRIVE%\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\Ax32.exe"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost, xComputerManagement

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		WindowsFeature RSAT-RDS-Tools {
			Ensure = "Present"
			Name = "RSAT-RDS-Tools"
			IncludeAllSubFeature = $true
		}

		WindowsFeature RDS-Licensing {
			Ensure = "Present"
			Name = "RDS-Licensing"
		}

		xRDSessionDeployment Deployment {
			DependsOn = "[CommonSetup]CommonSetup"

			ConnectionBroker = $localhost
			WebAccessServer = $gatewayServer
			SessionHosts = $sessionHosts

			PsDscRunAsCredential = $domainCreds
		}

		ConfigureRDSLicense ConfigureRDSLicense {
			DependsOn = "[xRDSessionDeployment]Deployment"

			domainName = $domainName
			adminCreds = $adminCreds
		}

		ConfigureRDSGateway ConfigureRDSGateway {
			
			domainName = $domainName
			adminCreds = $adminCreds
			gatewayServer = $gatewayServer
			loadBalancerFqdn = $loadBalancerFqdn
		}

		xRDSessionCollection Collection {
			DependsOn = "[ConfigureRDSGateway]ConfigureRDSGateway"

			ConnectionBroker = $localhost
			CollectionName = $collectionName
			CollectionDescription = "Remote applications collection"
			SessionHosts = $sessionHosts

			PsDscRunAsCredential = $domainCreds
		}

		xRDRemoteApp RemoteApp {
			DependsOn = "[xRDSessionCollection]Collection"
			
			Alias = "ax32"
			CollectionName = $collectionName
			DisplayName = "Microsoft Dynamics AX 2012"
			FilePath = $dynamicsAxClientFilePath
			FileVirtualPath = $dynamicsAxClientFileVirtualPath
			CommandLineSetting = "DoNotAllow"
			IconPath = $dynamicsAxClientFileVirtualPath
			ShowInWebAccess = $true

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration BIMachine {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$dbSqlServerDatabase,

		[Parameter(Mandatory)]
		[String]$aosServer,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[Parameter(Mandatory)]
		[String]$bcProxyAccount,

		[Parameter(Mandatory)]
		[String]$bcProxyAccountPassword,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$shortDomain = $domainName.Split(".")[0]
	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe
	$localhost = $env:COMPUTERNAME
	$localhostFqdn = "$localhost.$domainName"
	$userName = "$shortDomain\$($adminCreds.UserName)"
	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xCredSSP, xSqlServer, xDynamicsAX2012R3

	Node localhost {

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		xSqlServerSysAdmin SqlServerSysAdmin {
			DependsOn = "[CommonSetup]CommonSetup"

			ServerFqdn = $localhostFqdn
			Username = $userName
		}

		xSqlServerSysAdmin ReportServer {
			DependsOn = "[CommonSetup]CommonSetup"

			ServerFqdn = $localhostFqdn
			Username = "NT SERVICE\ReportServer"
		}

		xCredSSP Server {
            Ensure = "Present"
            Role = "Server"
        }

		xCredSSP Client {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = $localhostFqdn
        }

		xSqlServerFirewall ReportingServices {
			DependsOn = "[CommonSetup]CommonSetup"
			
			Ensure = "Present"
            SourcePath = $env:SystemDrive
            SourceFolder = "\SQLServer_12.0_Full"
            Features= "RS"
            InstanceName = "MSSQLSERVER"
		}

		xSqlServerRSConfig SqlServerRSConfig {
			DependsOn = "[xSqlServerSysAdmin]SqlServerSysAdmin"

			InstanceName = "MSSQLSERVER"
			RSSQLServer = $localhost
			RSSQLInstanceName = "MSSQLSERVER"
			SQLAdminCredential = $domainCreds
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsReportingAndAnalysis DynamicsReportingAndAnalysis {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			aosServer = $aosServer
			dbSqlServer = $dbSqlServer
			dbSqlServerDatabase = $dbSqlServerDatabase
			aosWsdlPort = $aosWsdlPort
			bcProxyAccount = $bcProxyAccount
			bcProxyAccountPassword = $bcProxyAccountPassword
			setupFile = $setupFile
			Ensure = "Present"

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration EPMachine {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$dbSqlServer,

		[Parameter(Mandatory)]
		[String]$aosServer,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[Parameter(Mandatory)]
		[String]$bcProxyAccount,

		[Parameter(Mandatory)]
		[String]$bcProxyAccountPassword,

		[Parameter(Mandatory)]
		[String]$spFarmPassphrase,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$shortDomain = $domainName.Split(".")[0]
	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$userName = "$shortDomain\$($adminCreds.UserName)"
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe
	$url = "http://$env:COMPUTERNAME"
	$webAppName = "SharePoint Sites"

	$restartIISScript = 
	{ 
		Invoke-Command -ScriptBlock { iisreset /restart }
	}

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xSharePoint, xDynamicsAX2012R3

	Node localhost {

		xMaxMemoryPerShell MaxMemoryPerShell {
			MaxMemoryPerShell = 8192
		}

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallReportViewer DownloadAndInstallReportViewer{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSharePointUpdate DownloadAndInstallSharePointUpdate{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLAMO DownloadAndInstallSQLAMO{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallMSChart DownloadAndInstallMSChart {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		xSPCreateFarm CreateSPFarm
		{
			DatabaseServer            = $dbSqlServer
			FarmConfigDatabaseName    = "SP_Config"
			Passphrase                = $spFarmPassphrase
			FarmAccount               = $domainCreds
			AdminContentDatabaseName  = "SP_AdminContent"
			CentralAdministrationPort = 2000

			PsDscRunAsCredential      = $domainCreds
		}

		xSPDistributedCacheService EnableDistributedCache
		{
			DependsOn            = "[xSPCreateFarm]CreateSPFarm"

			Name                 = "AppFabricCachingService"
			Ensure               = "Present"
			CacheSizeInMB        = 8192
			ServiceAccount       = $userName
			ServerProvisionOrder = @($env:COMPUTERNAME)
			CreateFirewallRules  = $true

			PsDscRunAsCredential   = $domainCreds
		}

		xSPWebApplication WebApplication
		{
			DependsOn            = "[xSPCreateFarm]CreateSPFarm"

			Name                   = $webAppName
			ApplicationPool        = $webAppName
			ApplicationPoolAccount = $userName
			AllowAnonymous         = $false
			AuthenticationMethod   = "NTLM"
			DatabaseName           = "SP_Content_01"
			DatabaseServer         = $dbSqlServer
			Url                    = $url
			Port                   = 80

			PsDscRunAsCredential   = $domainCreds
		}

		xSPSite SiteCollection
        {
			DependsOn            = "[xSPWebApplication]WebApplication"

            Url                  = $url
            OwnerAlias           = $userName
		
            PsDscRunAsCredential = $domainCreds
        }

		xSPServiceInstance ClaimsToWindowsTokenServiceInstance
        {  
			DependsOn            = "[xSPCreateFarm]CreateSPFarm"

            Name                 = "Claims to Windows Token Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $domainCreds
        }

		Script RestartIIS
		{
			SetScript = $restartIISScript

			TestScript = { return $false }
			
			GetScript = { return @{} }
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		xDynamicsEnterprisePortal xDynamicsEnterprisePortal {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			aosServer = $aosServer
			aosWsdlPort = $aosWsdlPort
			bcProxyAccount = $bcProxyAccount
			bcProxyAccountPassword = $bcProxyAccountPassword
			webAppName = $webAppName
			setupFile = $setupFile
			Ensure = "Present"

			PsDscRunAsCredential = $domainCreds
		}
	}
}

configuration RDSAndClientMachine {

	param (
		[Parameter(Mandatory)]
		[String]$domainName,

		[Parameter(Mandatory)]
		[PSCredential]$adminCreds,

		[Parameter(Mandatory)]
		[String]$aosServer,

		[Parameter(Mandatory)]
		[String]$aosWsdlPort,

		[String[]]$cumulativeUpdatesAndHotFixes
	)

	$domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
	$localhost = "$env::COMPUTERNAME.$domainName"
	$outputPath = Join-Path $env:SystemDrive -ChildPath temp
	$extractedPath = Join-Path $outputPath -ChildPath 6.3.164.0
	$setupFile = Join-Path $extractedPath -ChildPath setup.exe
	$collectionName = "RemoteApps"
	$dynamicsAxClientFilePath = "$env:systemdrive\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\Ax32.exe"
	$dynamicsAxClientFileVirtualPath = "%SYSTEMDRIVE%\Program Files (x86)\Microsoft Dynamics AX\60\Client\Bin\Ax32.exe"

	Import-DSCResource -ModuleName @{ModuleName="PSDesiredStateConfiguration";ModuleVersion="1.1"}, xRemoteDesktopSessionHost, xComputerManagement, xDynamicsAX2012R3

	Node localhost {

		LocalConfigurationManager {
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		}

		CommonSetup CommonSetup {
			domainName = $domainName
			adminCreds = $adminCreds
		}

		WindowsFeature NET-Framework-Core {
			Ensure = "Present"
			Name = "NET-Framework-Core"
		}

		WindowsFeature RDS-RD-Server {
			Ensure = "Present"
			Name = "RDS-RD-Server"
		}

		InstallRDS InstallRDS {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		xRDSessionDeployment Deployment {
			DependsOn = "[InstallRDS]InstallRDS"

			ConnectionBroker = $localhost
			WebAccessServer = $localhost
			SessionHosts = $localhost

			PsDscRunAsCredential = $domainCreds
		}

		xRDSessionCollection Collection {
			DependsOn = "[xRDSessionDeployment]Deployment"

			ConnectionBroker = $localhost
			CollectionName = $collectionName
			CollectionDescription = "Remote applications collection"
			SessionHosts = $localhost

			PsDscRunAsCredential = $domainCreds
		}

		DownloadAXSetup DownloadAXSetup {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		PrepareUpdatesAndHotFixes PrepareUpdatesAndHotFixes {
			DependsOn = "[DownloadAXSetup]DownloadAXSetup"

			cumulativeUpdatesAndHotFixes = $cumulativeUpdatesAndHotFixes
		}

		DownloadAndInstallMSChart DownloadAndInstallMSChart {
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLSysClrTypes DownloadAndInstallSQLSysClrTypes{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLAMO DownloadAndInstallSQLAMO{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallSQLADOMD DownloadAndInstallSQLADOMD{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		DownloadAndInstallReportViewer DownloadAndInstallReportViewer{
			DependsOn = "[CommonSetup]CommonSetup"
		}

		xDynamicsClient DynamicsClient {
			DependsOn = "[PrepareUpdatesAndHotFixes]PrepareUpdatesAndHotFixes"

			Ensure = "Present"
			aosServer = $aosServer
			aosWsdlPort = $aosWsdlPort
			setupFile = $setupFile

			PsDscRunAsCredential = $domainCreds
		}

		xRDRemoteApp RemoteApp {
			DependsOn = "[xRDSessionCollection]Collection"
			
			Alias = "ax32"
			CollectionName = $collectionName
			DisplayName = "Microsoft Dynamics AX 2012"
			FilePath = $dynamicsAxClientFilePath
			FileVirtualPath = $dynamicsAxClientFileVirtualPath
			CommandLineSetting = "DoNotAllow"
			IconPath = $dynamicsAxClientFileVirtualPath
			ShowInWebAccess = $true

			PsDscRunAsCredential = $domainCreds
		}
	}
}