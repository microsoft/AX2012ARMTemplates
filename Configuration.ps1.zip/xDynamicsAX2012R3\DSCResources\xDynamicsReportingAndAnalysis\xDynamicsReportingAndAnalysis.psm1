Import-Module "$PSScriptRoot\..\..\AX2012R3Deployment.psm1" -DisableNameChecking

function IsReportingServicesExtensionsInstalled
{
	$pathExists = Test-Path "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup\Components\ReportingServicesExtensions"

	if ($pathExists)
	{
		$value = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup\Components\ReportingServicesExtensions" | Select-Object -ExpandProperty "(default)"

		return $value -eq "Installed"
	}
	else
	{
		return $false
	}
}

function IsAnalysisServicesExtensionsInstalled
{
	$pathExists = Test-Path "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup\Components\AnalysisServicesExtensions"

	if ($pathExists)
	{
		$value = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup\Components\AnalysisServicesExtensions" | Select-Object -ExpandProperty "(default)"

		return $value -eq "Installed"
	}
	else
	{
		return $false
	}
}

function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $aosServer
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."


    <#
    $returnValue = @{
    dbSqlServer = [System.String]
    dbSqlServerDatabase = [System.String]
    aosInstanceName = [System.String]
    }

    $returnValue
    #>

	return @{}
}

function Set-TargetResource
{
    [CmdletBinding()]
    param
    (
		[parameter(Mandatory = $true)]
        [System.String]
        $aosServer,

		[parameter(Mandatory = $true)]
        [System.String]
        $dbSqlServer,

		[parameter(Mandatory = $true)]
        [System.String]
        $dbSqlServerDatabase,

		[parameter(Mandatory = $true)]
        [System.String]
        $aosWsdlPort,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccount,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccountPassword,

		[parameter(Mandatory = $true)]
		[System.String]
        $setupFile,

		[parameter(Mandatory = $true)]
        [ValidateSet("Present","Absent")]
        [System.String]
        $Ensure
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."

    #Include this line if the resource requires a system reboot.
    #$global:DSCMachineStatus = 1

	if ($Ensure -eq "Present")
	{
		$parmFileName = Join-Path $env:TEMP -ChildPath parm.ini
		$logDir = Join-Path $env:TEMP -ChildPath BIInstallLog

		Write-Verbose "Creating the Microsoft Dynamics AX parm.ini file at $parmFileName..."

		# Common parameters

		Write-Verbose "AcceptLicenseTerms=1" 
		"AcceptLicenseTerms=1" > $parmFileName

		Write-Verbose "LogDir=$LogDir" 
		"LogDir=`"$LogDir`"" >> $parmFileName

		Write-Verbose "ConfigurePrerequisites=1" 
		"ConfigurePrerequisites=1" >> $parmFileName

		Write-Verbose "HideUI=1" 
		"HideUI=1" >> $parmFileName

		Write-Verbose "UseMicrosoftUpdate=1"
		"UseMicrosoftUpdate=1">>$parmFileName

		# BI parameters

		#Reporting Services Extensions

		if (IsReportingServicesExtensionsInstalled -neq $true)
		{
			Write-Verbose "InstallReportingServicesExtensions=1" 
			"InstallReportingServicesExtensions=1" >> $parmFileName
		}

		#Analysis Services Extensions

		if (IsAnalysisServicesExtensionsInstalled -neq $true)
		{
			Write-Verbose "ConfigureAnalysisServices=1"
			"ConfigureAnalysisServices=1" >> $parmFileName
		}

		Write-Verbose "ClientAosServer=$aosServer" 
		"ClientAosServer=$aosServer" >> $parmFileName

		Write-Verbose "AosWsdlPort=$aosWsdlPort"
		"AosWsdlPort=$aosWsdlPort">> $parmFileName

		Write-Verbose "InstallManagementUtilities=1" 
		"InstallManagementUtilities=1" >> $parmFileName

		Write-Verbose "BusinessConnectorProxyAccount=$bcProxyAccount" 
		"BusinessConnectorProxyAccount=$bcProxyAccount" >> $parmFileName

		Write-Verbose "BusinessConnectorProxyAccountPassword=$bcProxyAccountPassword" 
		"BusinessConnectorProxyAccountPassword=$bcProxyAccountPassword" >> $parmFileName

		Write-Verbose "DbSqlServer=$dbSqlServer" 
		"DbSqlServer=$dbSqlServer" >> $parmFileName

		Write-Verbose "DbSqlDatabaseName=$dbSqlServerDatabase" 
		"DbSqlDatabaseName=$dbSqlServerDatabase" >> $parmFileName

		# Run AX Setup
		Run-AXSetup -parmFileName:$parmFileName -setupFile:$setupFile -logDir:$logDir
	}
	else
	{
		# TODO: uninstall data database and model database
	}
}

function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
		[parameter(Mandatory = $true)]
        [System.String]
        $aosServer,

		[parameter(Mandatory = $true)]
        [System.String]
        $dbSqlServer,

		[parameter(Mandatory = $true)]
        [System.String]
        $dbSqlServerDatabase,

		[parameter(Mandatory = $true)]
        [System.String]
        $aosWsdlPort,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccount,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccountPassword,

		[parameter(Mandatory = $true)]
		[System.String]
        $setupFile,

		[parameter(Mandatory = $true)]
        [ValidateSet("Present","Absent")]
        [System.String]
        $Ensure
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."


    <#
    $result = [System.Boolean]
    
    $result
    #>

	$isRSEInstalled = IsReportingServicesExtensionsInstalled
	$isASEInstalled = IsAnalysisServicesExtensionsInstalled

	if ($Ensure -eq "Present")
	{
		return $isRSEInstalled -and $isASEInstalled
	}
	else
	{
		if ($isRSEInstalled -or $isASEInstalled)
		{
			return $false
		}
	}
}


Export-ModuleMember -Function *-TargetResource