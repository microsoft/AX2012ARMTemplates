Import-Module "$PSScriptRoot\..\..\AX2012R3Deployment.psm1" -DisableNameChecking

function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [System.String]
        $aosServer
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."


    <#
    $returnValue = @{
    dbSqlServer = [System.String]
    dbSqlServerDatabase = [System.String]
    aosInstanceName = [System.String]
    }

    $returnValue
    #>

	return @{}
}

function Set-TargetResource
{
    [CmdletBinding()]
    param
    (
		[parameter(Mandatory = $true)]
        [System.String]
        $aosServer,

		[parameter(Mandatory = $true)]
        [System.String]
        $aosWsdlPort,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccount,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccountPassword,

		[parameter(Mandatory = $true)]
        [System.String]
		$webAppName,

		[parameter(Mandatory = $true)]
		[System.String]
        $setupFile,

		[parameter(Mandatory = $true)]
        [ValidateSet("Present","Absent")]
        [System.String]
        $Ensure
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."

    #Include this line if the resource requires a system reboot.
    #$global:DSCMachineStatus = 1

	if ($Ensure -eq "Present")
	{
		$parmFileName = Join-Path $env:TEMP -ChildPath parm.ini
		$logDir = Join-Path $env:TEMP -ChildPath EPInstallLog

		Write-Verbose "Creating the Microsoft Dynamics AX parm.ini file at $parmFileName..."

		# Common parameters

		Write-Verbose "AcceptLicenseTerms=1" 
		"AcceptLicenseTerms=1" > $parmFileName

		Write-Verbose "LogDir=$logDir" 
		"LogDir=`"$logDir`"" >> $parmFileName

		Write-Verbose "ConfigurePrerequisites=1" 
		"ConfigurePrerequisites=1" >> $parmFileName

		Write-Verbose "HideUI=1" 
		"HideUI=1" >> $parmFileName

		Write-Verbose "UseMicrosoftUpdate=1"
		"UseMicrosoftUpdate=1" >> $parmFileName

		# EP parameters

		Write-Verbose "InstallEnterprisePortal=1"
		"InstallEnterprisePortal=1" >> $parmFileName

		Write-Verbose "EnterprisePortalConfigureForWss=1" 
		"EnterprisePortalConfigureForWss=1" >> $parmFileName

		Write-Verbose "EnterprisePortalCreateWebSite=1"
		"EnterprisePortalCreateWebSite=1" >> $parmFileName

		Write-Verbose "EnterprisePortalWebSite=$webAppName" 
		"EnterprisePortalWebSite=$webAppName" >> $parmFileName

		Write-Verbose "ClientAosServer=$aosServer" 
		"ClientAosServer=$aosServer" >> $parmFileName

		Write-Verbose "AosWsdlPort=$aosWsdlPort"
		"AosWsdlPort=$aosWsdlPort">> $parmFileName

		Write-Verbose "InstallManagementUtilities=1" 
		"InstallManagementUtilities=1" >> $parmFileName

		Write-Verbose "BusinessConnectorProxyAccount=$bcProxyAccount" 
		"BusinessConnectorProxyAccount=$bcProxyAccount" >> $parmFileName

		Write-Verbose "BusinessConnectorProxyAccountPassword=$bcProxyAccountPassword" 
		"BusinessConnectorProxyAccountPassword=$bcProxyAccountPassword" >> $parmFileName

		# Run AX Setup
		Run-AXSetup -parmFileName:$parmFileName -setupFile:$setupFile -logDir:$logDir
	}
	else
	{
		# TODO: uninstall data database and model database
	}
}

function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
		[parameter(Mandatory = $true)]
        [System.String]
        $aosServer,

		[parameter(Mandatory = $true)]
        [System.String]
        $aosWsdlPort,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccount,

		[parameter(Mandatory = $true)]
        [System.String]
		$bcProxyAccountPassword,

		[parameter(Mandatory = $true)]
        [System.String]
		$webAppName,

		[parameter(Mandatory = $true)]
		[System.String]
        $setupFile,

		[parameter(Mandatory = $true)]
        [ValidateSet("Present","Absent")]
        [System.String]
        $Ensure
    )

    #Write-Verbose "Use this cmdlet to deliver information about command processing."

    #Write-Debug "Use this cmdlet to write debug information while troubleshooting."


    <#
    $result = [System.Boolean]
    
    $result
    #>

	return $false
}


Export-ModuleMember -Function *-TargetResource